﻿create database QLKS 
go
use QLKS
go

create table DICHVU (
   MaDV                 int identity(1,1)    not null,
   TenDV                nvarchar(60)         not null,
   GiaDV                money                not null,
   constraint PK_DICHVU primary key nonclustered (MaDV)
)
go

create table KHACHHANG (
   MaKH                 int identity(1,1)    not null,
   HoTen                nvarchar(100)        not null,
   CMND                 char(12) unique      null,
   DiaChi               nvarchar(150)        null,
   SDT                  char(10)             null,
   constraint PK_KHACHHANG primary key nonclustered (MaKH)
)
go

create table LOAIPHONG (
   MaLPH                int identity(1,1)    not null,
   LoaiPH               nvarchar(20)         not null,
   GiaPH                money                not null,
   constraint PK_LOAIPHONG primary key nonclustered (MaLPH)
)
go

create table NHANVIEN (
   MaNV                 int identity(1,1)    not null,
   MaTK                 int                  not null,
   HoTen                nvarchar(100)        not null,
   CMND                 char(12) unique      not null,
   DiaChi               nvarchar(150)        not null,
   NgayVaoLam           date                 not null,
   constraint PK_NHANVIEN primary key nonclustered (MaNV)
)
go

create index TAIKHOAN_FK on NHANVIEN (
MaTK ASC
)
go

create table PHIEUDV (
   MaPhieuDV            int identity(1,1)    not null,
   MaDV                 int                  not null,
   MaKH                 int                  not null,
   SoLanDV              int                  null,
   constraint PK_PHIEUDV primary key (MaDV, MaKH, MaPhieuDV)
)
go

create index PHIEUDV_FK on PHIEUDV (
MaPhieuDV ASC
)
go

create table PHONG (
   MaPH                 int identity(1,1)    not null,
   MaLPH                int                  not null,
   SoPH                 numeric(3) unique    not null,
   TinhTrangPH          nvarchar(6)			 not null,
   constraint PK_PHONG primary key nonclustered (MaPH)
)
go

create index LOAIPHONG_FK on PHONG (
MaLPH ASC
)
go

create table TAIKHOAN (
   MaTK                 int identity(1,1)    not null,
   TenDN                varchar(20) unique   not null,
   MatKhau              varchar(20)	         not null,
   ChucVu               nvarchar(10)         not null,
   constraint PK_TAIKHOAN primary key nonclustered (MaTK)
)
go

create table THUEPHONG (
   MaThuePH             int identity(1,1)    not null,
   MaPH                 int                  not null,
   MaKH                 int                  not null,
   NgayThue             date				 not null,
   NgayDuKienTra        date				 null,
   NgayTra              date				 null,
   DonGiaThue           money default 0      null,
   constraint PK_THUEPHONG primary key (MaThuePH, MaPH, MaKH)
)
go

create index THUEPHONG_FK on THUEPHONG (
MaThuePH ASC
)
go

create table VATTU (
   MaVT                 int identity(1,1)    not null,
   TenVT                nvarchar(60)         not null,
   constraint PK_VATTU primary key nonclustered (MaVT)
)
go

create table VATTUPHONG (
   MaPH                 int                  not null,
   MaVT                 int                  not null,
   SoLuong              int default 0        null,
   constraint PK_VATTUPHONG primary key (MaPH, MaVT)
)
go

create index TRANGBI_FK on VATTUPHONG (
MaPH ASC
)
go

create index TRANGBI2_FK on VATTUPHONG (
MaVT ASC
)
go

--Foreign key

alter table NHANVIEN
   add constraint FK_NHANVIEN_TAIKHOAN_TAIKHOAN foreign key (MaTK)
      references TAIKHOAN (MaTK)
go

alter table PHIEUDV
   add constraint FK_PHIEUDV_PHIEUDV_DICHVU foreign key (MaDV)
      references DICHVU (MaDV)
go

alter table PHIEUDV
   add constraint FK_PHIEUDV_PHIEUDV2_KHACHHAN foreign key (MaKH)
      references KHACHHANG (MaKH)
go

alter table PHONG
   add constraint FK_PHONG_LOAIPHONG_LOAIPHON foreign key (MaLPH)
      references LOAIPHONG (MaLPH)
go

alter table THUEPHONG
   add constraint FK_THUEPHON_THUEPHONG_PHONG foreign key (MaPH)
      references PHONG (MaPH)
go

alter table THUEPHONG
   add constraint FK_THUEPHON_THUEPHONG_KHACHHAN foreign key (MaKH)
      references KHACHHANG (MaKH)
go

alter table VATTUPHONG
   add constraint FK_VATTUPHO_VATTUPHON_PHONG foreign key (MaPH)
      references PHONG (MaPH)
go

alter table VATTUPHONG
   add constraint FK_VATTUPHO_VATTUPHON_VATTU foreign key (MaVT)
      references VATTU (MaVT)
go

--INSERT
--DATEFORMAT yyyy-MM-dd

insert DICHVU values(N'Trông trẻ', 100000)
insert DICHVU values(N'Giặt ủi', 50000)
insert DICHVU values(N'Dọn dẹp phòng', 80000)

insert VATTU values(N'Khăn tắm')
insert VATTU values(N'Dầu gội')
insert VATTU values(N'Sữa tắm')
insert VATTU values(N'Móc treo đồ')
insert VATTU values(N'Kem đánh răng')

insert LOAIPHONG values(N'1 Người',100000)
insert LOAIPHONG values(N'2 Người',175000)
insert LOAIPHONG values(N'3 Người',225000)
insert LOAIPHONG values(N'4 Người',300000)

insert PHONG values(1,101, N'Trống')
insert PHONG values(1,102, N'Trống')
insert PHONG values(2,201, N'Trống')
insert PHONG values(2,202, N'Trống')
insert PHONG values(3,301, N'Trống')
insert PHONG values(3,302, N'Trống')
insert PHONG values(4,401, N'Trống')
insert PHONG values(4,402, N'Trống')

insert VATTUPHONG values(1,1,2)
insert VATTUPHONG values(1,2,1)
insert VATTUPHONG values(1,3,2)
insert VATTUPHONG values(1,5,1)
insert VATTUPHONG values(2,4,1)
insert VATTUPHONG values(2,5,1)
insert VATTUPHONG values(3,2,2)
insert VATTUPHONG values(3,4,1)
insert VATTUPHONG values(3,5,2)
insert VATTUPHONG values(5,1,1)
insert VATTUPHONG values(5,5,1)
insert VATTUPHONG values(6,2,3)
insert VATTUPHONG values(7,2,2)
insert VATTUPHONG values(7,4,1)
insert VATTUPHONG values(8,1,4)


insert KHACHHANG values(N'Đoàn thị Âu', '079030751234', N'112/2 Nguyễn Hữu Cảnh', '0967543611')
insert KHACHHANG values(N'Phan Đào Trung', '070010200221', N'12/12 Trịnh Quang Nghị', '0861776620')
insert KHACHHANG values(N'Đoàn Mỹ Ân', '066021112660', N'151/31 Nguyển Du', '0910464120')
insert KHACHHANG values(N'Nguyễn Hà Long', '012010250091', N'38/18 Nguyễn Văn Luông', '0613159877')

insert THUEPHONG values(3,2,'2008-12-2','2008-12-8','2008-12-8', 700000)
insert THUEPHONG values(6,1,'2008-5-1','2008-5-8','2008-5-8', 875000)
insert THUEPHONG values(6,2,'2009-1-12','2009-1-14','2009-1-15', 700000)
insert THUEPHONG values(8,3,'2011-6-28','2011-7-1','2011-7-3', 1800000)

insert PHIEUDV values(3,1,2)
insert PHIEUDV values(1,3,1)
insert PHIEUDV values(1,2,1)
insert PHIEUDV values(2,4,3)
insert PHIEUDV values(3,3,3)

insert TAIKHOAN values('nhanvien123456','123456', N'Nhân viên')
insert TAIKHOAN values('quanly123456','123456', N'Quản lý')
 
insert NHANVIEN values(1,N'Nguyễn Minh Thanh', '073045478796',N'144/21 Lý Thường Kiệt','2000-8-2')
insert NHANVIEN values(1,N'Đào Trọng Lộc', '057021490012',N'124/2/32 Lê Lợi','2000-3-1')
insert NHANVIEN values(1,N'Nguyễn Phương Mai', '070049099701',N'213/1 Nguyễn Văn Linh','2004-1-30')
insert NHANVIEN values(2,N'Phạm Trung Tiến', '033010411033',N'123/4 Nguyễn Khắc Viện','1994-1-1')
insert NHANVIEN values(1,N'Phạm Quang Đức', '010021024913',N'109/7/1 Nguyễn Văn Linh','2001-8-11')

--PROCEDURE
go
create procedure Display_Phong
as
begin
select MaPH, SoPH, TinhTrangPH, LoaiPH, GiaPH from PHONG inner join LOAIPHONG on(PHONG.MaLPH=LOAIPHONG.MaLPH)
end

go
create procedure Update_TTP
	@MaPH int,
	@TinhTrang nvarchar(6)
as
begin
	if(@TinhTrang = N'Trống')
		update PHONG set TinhTrangPH=N'Trống' where MaPH = @MaPH
	else
		update PHONG set TinhTrangPH=N'Thuê' where MaPH = @MaPH
end

go
create procedure Display_VTP
	@MaPH int
as
begin
	select VATTU.MaVT, TenVT, SoLuong from VATTU inner join VATTUPHONG on(VATTU.MaVT=VATTUPHONG.MaVT) where VATTUPHONG.MaPH=@MaPH
end

go
create procedure Insert_VTP
	@MaPH int,
	@MaVT int,
	@SoLuong int
as
begin
	insert VATTUPHONG values(@MaPH, @MaVT, @SoLuong)
end

go 
create procedure Update_VTP
	@MaPH int,
	@MaVT int,
	@SoLuong int
as
begin
	update VATTUPHONG set SoLuong = @SoLuong where MaPH = @MaPH and MaVT = @MaVT
end

go 
create procedure Del_VTP
	@MaPH int,
	@MaVT int
as
begin 
	delete from VATTUPHONG where MaPH = @MaPH and MaVT = @MaVT
end

go
create procedure Display_KH
as
begin
	select * from KHACHHANG
end

go
create procedure Insert_KH
	@HoTen nvarchar(100),
	@CMND char(12),
	@DiaChi nvarchar(150),
	@SDT char(10)
as
begin
	insert KHACHHANG values(@HoTen, @CMND, @DiaChi, @SDT)
end

go
create procedure Update_KH
	@MaKH int,
	@HoTen nvarchar(100),
	@CMND char(12),
	@DiaChi nvarchar(150),
	@SDT char(10)
as
begin
	update KHACHHANG set HoTen = @HoTen, CMND = @CMND, DiaChi = @DiaChi, SDT = @SDT where MaKH = @MaKH
end

go 
create procedure Display_TP
	@MaKH int
as
begin
	select CMND,THUEPHONG.MaThuePH, PHONG.MaPH, SoPH, NgayThue, NgayDuKienTra, NgayTra 
	from KHACHHANG join THUEPHONG on(KHACHHANG.MaKH = THUEPHONG.MaKH) join PHONG on(THUEPHONG.MaPH = PHONG.MaPH) 
	where KHACHHANG.MaKH = @MaKH
end

go
create procedure Insert_TP
	@MaPH int,
	@MaKH int,
	@NgayThue date,
	@NgayDuKienTra date
as
begin
	insert THUEPHONG values(@MaPH, @MaKH, @NgayThue, @NgayDuKienTra, @NgayDuKienTra, 0)
end

go
create procedure Update_TP
	@MaThuePH int,
	@MaPH int,
	@MaKH int,
	@NgayThue date,
	@NgayDuKienTra date
as
begin
	update THUEPHONG set MaPH = @MaPH, MaKH = @MaKH, NgayThue = @NgayThue, NgayDuKienTra = @NgayDuKienTra where MaThuePH = @MaThuePH
end

go
create procedure Update_NT
	@MaThuePH int,
	@NgayTra date
as
begin
	update THUEPHONG set NgayTra = @NgayTra where MaThuePH = @MaThuePH
end

go 
create procedure Display_PhieuDV
as
begin
	select MaPhieuDV, DICHVU.MaDV, KHACHHANG.MaKH, CMND, TenDV, SoLanDV  
	from PHIEUDV join DICHVU on(PHIEUDV.MaDV = DICHVU.MaDV) join KHACHHANG on (PHIEUDV.MaKH = KHACHHANG.MaKH)
end

go
create procedure Insert_PhieuDV
	@MaDV int,
	@MaKH int,
	@SoLanDV int
as
begin
	insert PHIEUDV values(@MaDV, @MaKH, @SoLanDV)
end

go
create procedure Update_PhieuDV
	@MaPhieuDV int,
	@MaDV int,
	@MaKH int,
	@SoLanDV int
as 
begin
	update PHIEUDV set MaDV=@MaDV, MaKH=@MaKH, SoLanDV=@SoLanDV where MaPhieuDV=@MaPhieuDV
end

go
create procedure Del_PhieuDV
	@MaPhieuDV int
as
begin
	delete from PHIEUDV where MaPhieuDV=@MaPhieuDV
end

go 
create procedure Display_NhanVien
as
begin
	select MaNV, HoTen, CMND, DiaChi, NgayVaoLam, ChucVu from NHANVIEN join TAIKHOAN on(NHANVIEN.MaTK=TAIKHOAN.MaTK)
end

go
create procedure Insert_NhanVien
	@MaTK int,
	@HoTen nvarchar(100),
	@CMND char(12),
	@DiaChi nvarchar(150),
	@NgayVaoLam date
as
begin
	insert NHANVIEN values(@MaTK,@HoTen,@CMND,@DiaChi,@NgayVaoLam)
end

go
create procedure Update_nhanVien
	@maNV int,
	@MaTK int,
	@HoTen nvarchar(100),
	@CMND char(12),
	@DiaChi nvarchar(150),
	@NgayVaoLam date
as
begin
	update NHANVIEN set MaTK=@MaTK, HoTen=@HoTen, CMND=@CMND, DiaChi=@DiaChi, NgayVaoLam=@NgayVaoLam where MaNV=@maNV
end

go
create procedure Del_NhanVien
	@MaNV int
as
begin
	delete from NHANVIEN where MaNV=@MaNV
end

go
create procedure Display_TaiKhoan
as
begin
	select *from TAIKHOAN
end

go
create procedure Update_TaiKhoan
	@MaTK int,
	@TenDN varchar(20),
	@MatKhau varchar(20)
as
begin
	update TAIKHOAN set TenDN=@TenDN, MatKhau=@MatKhau where MaTK=@MaTK
end

go
create procedure Display_DichVu
as
begin
	select * from DICHVU
end

go 
create procedure Insert_DichVu
	@TenDV nvarchar(60),
	@GiaDV money
as
begin
	insert DICHVU values(@TenDV,@GiaDV)
end

go 
create procedure Update_DichVu
	@MaDV int,
	@TenDV nvarchar(60),
	@GiaDV money
as
begin
	update DICHVU set TenDV=@TenDV, GiaDV=@GiaDV where MaDV=@MaDV
end

go 
create procedure Del_DichVu
	@MaDV int
as
begin
	delete from PHIEUDV where MaDV=@MaDV
	delete from DICHVU where MaDV=@MaDV
end

go 
create procedure Insert_Phong
	@MaLP int,
	@SoPH numeric(3),
	@TinhTrang nvarchar(6)
as
begin
	insert PHONG values(@MaLP,@SoPH,@TinhTrang)
end

go
create procedure Update_Phong
	@MaPH int,
	@MaLP int,
	@SoPH numeric(3),
	@TinhTrang nvarchar(6)
as
begin
	update PHONG set MaLPH=@MaLP, SoPH=@SoPH, TinhTrangPH=@TinhTrang where MaPH=@MaPH
end

go
create procedure Del_Phong
	@MaPH int
as
begin
	delete from VATTUPHONG where MaPH=@MaPH
	delete from THUEPHONG where MaPH=@MaPH
	delete from PHONG where MaPH=@MaPH
end

go
create procedure Display_LP
as
begin
	select * from LOAIPHONG
end

go
create procedure Insert_LP
	@LoaiPH nvarchar(20),
	@GiaPH money
as
begin
	insert LOAIPHONG values(@LoaiPH,@GiaPH)
end

go
create procedure Update_LP
	@MaLPH int,
	@LoaiPH nvarchar(20),
	@GiaPH money
as
begin
	update LOAIPHONG set LoaiPH=@LoaiPH, GiaPH=@GiaPH where MaLPH=@MaLPH
end

go
create procedure Del_LP
	@MaLPH int
as
begin
	delete from PHONG where MaLPH=@MaLPH
	delete from LOAIPHONG where MaLPH=@MaLPH
end

go
create procedure Check_Login
	@TenDN varchar(20),
	@MK varchar(20)
as
begin
	select count(*) from TAIKHOAN where TenDN=@TenDN and MatKhau=@MK
end
go
create procedure Check_User
	@TenDN varchar(20)
as
begin
	select count(*) from TAIKHOAN where TenDN=@TenDN
end

go
create procedure Check_Role
	@TenDN varchar(20),
	@MK varchar(20)
as
begin
	select ChucVu from TAIKHOAN where TenDN=@TenDN and MatKhau=@MK
end