### Đề tài: Quản lý khách sạn
### Cách cài đặt:
* ##### Database: 
[Cài đặt SQL Server](https://howkteam.vn/course/huong-dan-cai-dat/cai-dat-sql-server-2019-4058)
Cài đăt xong khởi động Microsoft SQL Server Management Studio chỉnh:
Server type: Database Engine 
Server name: phải có phần \SQLEXPRESS (VD: DESKTOP\SQLEXPRESS) 
Authertication: Windows Authertication

Sau đó nhấn Connect để kết nối, chọn File -> Open ->File -> chọn file QLKS.sql 
Cuối cùng nhấn Excute(hoặc F5) là xong

* ##### Soucre Code
[Cài Đặt .NET 4.7.2](https://dotnet.microsoft.com/en-us/download/dotnet-framework/net472)
