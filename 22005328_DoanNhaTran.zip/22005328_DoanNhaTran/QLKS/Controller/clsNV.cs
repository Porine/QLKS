﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsNV
    {
        ClsProvider db = new ClsProvider();

        public DataTable Display_NhanVien()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_NhanVien";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Insert_NhanVien(int MaTK, string hoten, string cmnd, string dc, string ngay)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_NhanVien";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaTK", MaTK));
                cmd.Parameters.Add(new SqlParameter("@HoTen", hoten));
                cmd.Parameters.Add(new SqlParameter("@CMND", cmnd));
                cmd.Parameters.Add(new SqlParameter("@DiaChi", dc));
                cmd.Parameters.Add(new SqlParameter("@NgayVaoLam", ngay));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Update_NhanVien(int MaNV, int MaTK, string hoten, string cmnd, string dc, string ngay)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_NhanVien";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaNV", MaNV));
                cmd.Parameters.Add(new SqlParameter("@MaTK", MaTK));
                cmd.Parameters.Add(new SqlParameter("@HoTen", hoten));
                cmd.Parameters.Add(new SqlParameter("@CMND", cmnd));
                cmd.Parameters.Add(new SqlParameter("@DiaChi", dc));
                cmd.Parameters.Add(new SqlParameter("@NgayVaoLam", ngay));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Del_NhanVien(int MaNV)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Del_NhanVien";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaNV", MaNV));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }
    }
}
