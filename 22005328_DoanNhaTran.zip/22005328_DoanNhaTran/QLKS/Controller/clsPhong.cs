﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsPhong
    {
        ClsProvider db = new ClsProvider();
        
        public DataTable Display_Phong()
        {   
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_Phong";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Update_TTPhong(int MaPH, string TinhTrang)
        {
            int rec = 0;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_TTP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@TinhTrang", TinhTrang));
                rec = cmd.ExecuteNonQuery();

            }
            else rec = -1;
            return rec;
        }
    }
}
