﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsTP
    {
        ClsProvider db = new ClsProvider();
        public DataTable Display_TP(int MaKH)
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_TP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public SqlDataReader Display_TPcbSoPhong()
        {
            SqlDataReader dr = null;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select SoPH from PHONG";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
            }

            return dr;
        }

        public int Insert_TP(int MaPH, int MaKH, string NT, string NDK)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_TP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                cmd.Parameters.Add(new SqlParameter("@NgayThue", NT));
                cmd.Parameters.Add(new SqlParameter("@NgayDuKienTra", NDK));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Update_TP(int MathuePH, int MaPH, int MaKH, string NT, string NDK)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_TP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaThuePH", MathuePH));
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                cmd.Parameters.Add(new SqlParameter("@NgayThue", NT));
                cmd.Parameters.Add(new SqlParameter("@NgayDuKienTra", NDK));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Update_NT(int MathuePH, string NT)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_NT";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaThuePH", MathuePH));
                cmd.Parameters.Add(new SqlParameter("@NgayTra", NT));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }
    }
}
