﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsVTP
    {
        ClsProvider db = new ClsProvider();

        public DataTable Display_VTP(int MaPH)
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_VTP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Insert_VTP(int MaPH, int MaVT, int SL)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_VTP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@MaVT", MaVT));
                cmd.Parameters.Add(new SqlParameter("@SoLuong", SL));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch(SqlException)
                {
                    rec = -2;
                }
                
            }
            else rec = -1;
            return rec;
        }

        public int Update_VTP(int MaPH, int MaVT, int SL)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_VTP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@MaVT", MaVT));
                cmd.Parameters.Add(new SqlParameter("@SoLuong", SL));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Del_VTP(int MaPH, int MaVT)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Del_VTP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", MaPH));
                cmd.Parameters.Add(new SqlParameter("@MaVT", MaVT));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }
    }
}
