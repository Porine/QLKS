﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsQLPH
    {
        ClsProvider db = new ClsProvider();

        #region Phong
        public DataTable Display_Phong()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_Phong";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Insert_Phong(int malp, int soph, string tt)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_Phong";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaLP", malp));
                cmd.Parameters.Add(new SqlParameter("@SoPH", soph));
                cmd.Parameters.Add(new SqlParameter("@TinhTrang", tt));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Update_Phong(int maph, int malp, int soph, string tt)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_Phong";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", maph));
                cmd.Parameters.Add(new SqlParameter("@MaLP", malp));
                cmd.Parameters.Add(new SqlParameter("@SoPH", soph));
                cmd.Parameters.Add(new SqlParameter("@TinhTrang", tt));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Del_Phong(int maph)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Del_Phong";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPH", maph));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public void DisplayPH_cbLP(System.Windows.Forms.ComboBox cb)
        {
            SqlDataReader dr;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select LoaiPH from LOAIPHONG";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
            }
            else dr = null;

            while (dr.Read())
            {
                cb.Items.Add(dr["LoaiPH"].ToString());
            }
        }

        public int GetIDLPfromLoaiPH(string lp)
        {
            int malp=0;
            SqlDataReader dr;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select MaLPH from LOAIPHONG where LoaiPH=N'"+lp+"'";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
            }
            else dr = null;

            if (dr == null) malp = 0;
            else
            {
                while (dr.Read())
                {
                    malp = int.Parse(dr["MaLPH"].ToString());
                }
            }
            return malp;
        }

        #endregion

        public DataTable Display_LP()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_LP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Insert_LP( string lp, float gia)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_LP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@LoaiPH", lp));
                cmd.Parameters.Add(new SqlParameter("@GiaPH", gia));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Update_LP(int malph, string lp, float gia)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_LP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaLPH", malph));
                cmd.Parameters.Add(new SqlParameter("@LoaiPH", lp));
                cmd.Parameters.Add(new SqlParameter("@GiaPH", gia));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }

        public int Del_LP(int malp)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Del_LP";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaLPH", malp));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }
    }
}
