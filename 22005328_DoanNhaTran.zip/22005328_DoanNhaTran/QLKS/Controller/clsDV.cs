﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsDV
    {
        ClsProvider db = new ClsProvider();

        public DataTable Display_PhieuDV()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_PhieuDV";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public SqlDataReader Display_DVcbCMND()
        {
            SqlDataReader dr = null;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select CMND from KHACHHANG";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
            }

            return dr;
        }

        public SqlDataReader Display_DVcbTenDV()
        {
            SqlDataReader dr = null;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Select TenDV from DICHVU";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
            }

            return dr;
        }

        public int GetMAKHfromCMND(string CMND)
        {
            int maKH=-1;
            SqlDataReader dr;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select MaKH from KHACHHANG where CMND=" + CMND;
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    maKH = int.Parse(dr["MaKH"].ToString());
                }
            }
            return maKH;
        }

        public int GetMADVfromTenDV(string TenDv)
        {
            int maDV = -1;
            SqlDataReader dr;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select MaDV from DICHVU where TenDV=N'" + TenDv+"'";
                cmd.Connection = db.conn;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    maDV = int.Parse(dr["MaDV"].ToString());
                }
            }
            return maDV;
        }

        public int Insert_PhieuDV(int MaDV, int MaKH, int sl)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_PhieuDV";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaDV", MaDV));
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                cmd.Parameters.Add(new SqlParameter("@SoLanDV", sl));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Update_PhieuDV(int maPHDV, int MaDV, int MaKH, int sl)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_PhieuDV";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPhieuDV", maPHDV));
                cmd.Parameters.Add(new SqlParameter("@MaDV", MaDV));
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                cmd.Parameters.Add(new SqlParameter("@SoLanDV", sl));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Del_PhieuDV(int maPHDV)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Del_PhieuDV";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaPhieuDV", maPHDV));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }
    }
}
