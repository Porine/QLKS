﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsCheckUser
    {
        ClsProvider db = new ClsProvider();

        public int CheckUser(string tendn, string mk)
        {
            int rec, count;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Check_User";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@TenDN", tendn));
                count = (int)cmd.ExecuteScalar();
                if (count == 1)
                {
                    SqlCommand cmd2 = new SqlCommand();
                    cmd2.CommandText = "Check_Login";
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Connection = db.conn;
                    cmd2.Parameters.Add(new SqlParameter("@TenDN", tendn));
                    cmd2.Parameters.Add(new SqlParameter("@MK", mk));
                    rec = (int)cmd2.ExecuteScalar();
                }
                else rec = -2;
            }
            else rec = -1;
            return rec;
        }

        public int CheckRole(string tendn, string mk)
        {
            int rec=-1;
            if (db.Connection())
            {
                SqlDataReader dr;
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Check_Role";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@TenDN", tendn));
                cmd.Parameters.Add(new SqlParameter("@MK", mk));
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr["ChucVu"].ToString() == "Nhân viên") rec = 0;
                    else rec = 1;
                    break;
                }
            }
            else rec = -1;
            return rec;
        }
    }
}
