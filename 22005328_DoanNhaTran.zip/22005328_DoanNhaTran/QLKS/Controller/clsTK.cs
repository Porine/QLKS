﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsTK
    {
        ClsProvider db = new ClsProvider();

        public DataTable Display_TaiKhoan()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_TaiKhoan";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Update_TaiKhoan(int matk, string tendn, string mk)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_TaiKhoan";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaTK", matk));
                cmd.Parameters.Add(new SqlParameter("@TenDN", tendn));
                cmd.Parameters.Add(new SqlParameter("@MatKhau", mk));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }
            }
            else rec = -1;
            return rec;
        }
    }
}
