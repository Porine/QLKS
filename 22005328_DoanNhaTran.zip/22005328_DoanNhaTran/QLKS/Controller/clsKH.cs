﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QLKS.Model;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Controller
{
    class clsKH
    {
        ClsProvider db = new ClsProvider();
        public DataTable Display_KH()
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Display_KH";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public DataTable GetTTKH(int MaKH)
        {
            DataTable dt = new DataTable();
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "select * from KHACHHANG where MaKH="+MaKH;
                cmd.Connection = db.conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            return dt;
        }

        public int Insert_KH(string Hoten, string CMND, string DC, string SDT)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert_KH";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@HoTen", Hoten));
                cmd.Parameters.Add(new SqlParameter("@CMND", CMND));
                cmd.Parameters.Add(new SqlParameter("@DiaChi", DC));
                cmd.Parameters.Add(new SqlParameter("@SDT", SDT));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }

        public int Update_KH(int MaKH, string Hoten, string CMND, string DC, string SDT)
        {
            int rec;
            if (db.Connection())
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Update_KH";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = db.conn;
                cmd.Parameters.Add(new SqlParameter("@MaKH", MaKH));
                cmd.Parameters.Add(new SqlParameter("@HoTen", Hoten));
                cmd.Parameters.Add(new SqlParameter("@CMND", CMND));
                cmd.Parameters.Add(new SqlParameter("@DiaChi", DC));
                cmd.Parameters.Add(new SqlParameter("@SDT", SDT));
                try
                {
                    rec = cmd.ExecuteNonQuery();
                }
                catch (SqlException)
                {
                    rec = -2;
                }

            }
            else rec = -1;
            return rec;
        }
    }
}
