﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLKS.Controller;

namespace QLKS.Views
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        clsCheckUser cu = new clsCheckUser();

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (txtTenDN.TextLength == 0)
            {
                MessageBox.Show("Tên đăng nhập không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtTenDN.Focus();
            }
            else if (txtTenDN.TextLength > 20)
            {
                MessageBox.Show("Tên đăng nhập không được quá 20 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                txtTenDN.Focus();
            }
            else if (txtMK.TextLength == 0)
            {
                MessageBox.Show("Mật khẩu không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtMK.Focus();
            }
            else if (txtMK.TextLength > 20)
            {
                MessageBox.Show("Mật khẩu không được quá 20 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                txtMK.Focus();
            }
            else
            {
                if (txtMK.Text.Trim().Length == 0) txtMK.Text = "";
                int rec = cu.CheckUser(txtTenDN.Text, txtMK.Text);
                if (rec > 0)
                {
                    MessageBox.Show("Đăng nhập thành công!", "Thông báo!", MessageBoxButtons.OK);
                    int cr = cu.CheckRole(txtTenDN.Text, txtMK.Text);
                    if(cr == 0)
                    {
                        Main_QLKS frm = new Main_QLKS();
                        frm.Show();
                    }
                    else if (cr == 1)
                    {
                        MainManager_QLKS frm = new MainManager_QLKS();
                        frm.Show();
                    }
                    this.Hide();
                    
                }
                else if (rec == -2)
                {
                    MessageBox.Show("Tên đăng nhập sai!", "Thông báo!", MessageBoxButtons.OK);
                    txtTenDN.Focus();
                }
                else if(rec == 0)
                {
                    MessageBox.Show("Mật khẩu sai!", "Thông báo!", MessageBoxButtons.OK);
                    txtMK.Focus();
                }
                else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
            }
        }

        private void txtTenDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsWhiteSpace(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar)) e.Handled = true;
        }
    }
}
