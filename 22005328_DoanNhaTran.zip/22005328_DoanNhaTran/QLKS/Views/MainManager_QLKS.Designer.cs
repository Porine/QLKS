﻿
namespace QLKS.Views
{
    partial class MainManager_QLKS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabQLNV = new System.Windows.Forms.TabPage();
            this.dgv_QLNV = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbNV_ChucVu = new System.Windows.Forms.ComboBox();
            this.dtpNV_NVL = new System.Windows.Forms.DateTimePicker();
            this.btnNV_Save = new System.Windows.Forms.Button();
            this.btnNV_Del = new System.Windows.Forms.Button();
            this.btnNV_Update = new System.Windows.Forms.Button();
            this.btnNV_Insert = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNV_CMND = new System.Windows.Forms.TextBox();
            this.txtNV_DC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNV_HoTen = new System.Windows.Forms.TextBox();
            this.txtGetIDNV = new System.Windows.Forms.TextBox();
            this.tabQLTK = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnTK_Save = new System.Windows.Forms.Button();
            this.btnTK_Update = new System.Windows.Forms.Button();
            this.txtTK_MK = new System.Windows.Forms.TextBox();
            this.txtTK_TenDN = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvTK = new System.Windows.Forms.DataGridView();
            this.txtGetIDTK = new System.Windows.Forms.TextBox();
            this.tabQLDV = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnDV_Save = new System.Windows.Forms.Button();
            this.btnDV_Del = new System.Windows.Forms.Button();
            this.btnDV_Update = new System.Windows.Forms.Button();
            this.btnDV_Insert = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDV_GiaDV = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDV_TenDV = new System.Windows.Forms.TextBox();
            this.dgvQLDV = new System.Windows.Forms.DataGridView();
            this.txtGetIDDV_QL = new System.Windows.Forms.TextBox();
            this.tabQLPH = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.grLP = new System.Windows.Forms.GroupBox();
            this.txtLP_LoaiPH = new System.Windows.Forms.TextBox();
            this.txtLP_Gia = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnPH_DisplayLPH = new System.Windows.Forms.Button();
            this.btnPH_DisplayPH = new System.Windows.Forms.Button();
            this.btnPH_Save = new System.Windows.Forms.Button();
            this.btnPH_Del = new System.Windows.Forms.Button();
            this.btnPH_Update = new System.Windows.Forms.Button();
            this.btnPH_Insert = new System.Windows.Forms.Button();
            this.grPhong = new System.Windows.Forms.GroupBox();
            this.cbPH_LP = new System.Windows.Forms.ComboBox();
            this.cbPH_TT = new System.Windows.Forms.ComboBox();
            this.txtPH_SoPH = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dgvPH = new System.Windows.Forms.DataGridView();
            this.txtGetIDLP = new System.Windows.Forms.TextBox();
            this.txtGetIDPH = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabQLNV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_QLNV)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabQLTK.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).BeginInit();
            this.tabQLDV.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLDV)).BeginInit();
            this.tabQLPH.SuspendLayout();
            this.panel4.SuspendLayout();
            this.grLP.SuspendLayout();
            this.grPhong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPH)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabQLNV);
            this.tabControl1.Controls.Add(this.tabQLTK);
            this.tabControl1.Controls.Add(this.tabQLDV);
            this.tabControl1.Controls.Add(this.tabQLPH);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(941, 517);
            this.tabControl1.TabIndex = 0;
            // 
            // tabQLNV
            // 
            this.tabQLNV.Controls.Add(this.dgv_QLNV);
            this.tabQLNV.Controls.Add(this.panel1);
            this.tabQLNV.Controls.Add(this.txtGetIDNV);
            this.tabQLNV.Location = new System.Drawing.Point(4, 29);
            this.tabQLNV.Name = "tabQLNV";
            this.tabQLNV.Padding = new System.Windows.Forms.Padding(3);
            this.tabQLNV.Size = new System.Drawing.Size(933, 484);
            this.tabQLNV.TabIndex = 0;
            this.tabQLNV.Text = "Quản lý nhân viên";
            this.tabQLNV.UseVisualStyleBackColor = true;
            // 
            // dgv_QLNV
            // 
            this.dgv_QLNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_QLNV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgv_QLNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_QLNV.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_QLNV.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgv_QLNV.Location = new System.Drawing.Point(3, 248);
            this.dgv_QLNV.Name = "dgv_QLNV";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_QLNV.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_QLNV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.dgv_QLNV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_QLNV.Size = new System.Drawing.Size(927, 233);
            this.dgv_QLNV.TabIndex = 2;
            this.dgv_QLNV.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbNV_ChucVu);
            this.panel1.Controls.Add(this.dtpNV_NVL);
            this.panel1.Controls.Add(this.btnNV_Save);
            this.panel1.Controls.Add(this.btnNV_Del);
            this.panel1.Controls.Add(this.btnNV_Update);
            this.panel1.Controls.Add(this.btnNV_Insert);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtNV_CMND);
            this.panel1.Controls.Add(this.txtNV_DC);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtNV_HoTen);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(927, 230);
            this.panel1.TabIndex = 3;
            // 
            // cbNV_ChucVu
            // 
            this.cbNV_ChucVu.Enabled = false;
            this.cbNV_ChucVu.FormattingEnabled = true;
            this.cbNV_ChucVu.Items.AddRange(new object[] {
            "Nhân viên",
            "Quản lý"});
            this.cbNV_ChucVu.Location = new System.Drawing.Point(622, 43);
            this.cbNV_ChucVu.Name = "cbNV_ChucVu";
            this.cbNV_ChucVu.Size = new System.Drawing.Size(218, 28);
            this.cbNV_ChucVu.TabIndex = 2;
            this.cbNV_ChucVu.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbNV_ChucVu_KeyPress);
            // 
            // dtpNV_NVL
            // 
            this.dtpNV_NVL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtpNV_NVL.CustomFormat = "dd-MM-yyyy";
            this.dtpNV_NVL.Enabled = false;
            this.dtpNV_NVL.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNV_NVL.Location = new System.Drawing.Point(196, 169);
            this.dtpNV_NVL.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpNV_NVL.Name = "dtpNV_NVL";
            this.dtpNV_NVL.Size = new System.Drawing.Size(135, 27);
            this.dtpNV_NVL.TabIndex = 5;
            // 
            // btnNV_Save
            // 
            this.btnNV_Save.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNV_Save.Enabled = false;
            this.btnNV_Save.Location = new System.Drawing.Point(773, 155);
            this.btnNV_Save.Name = "btnNV_Save";
            this.btnNV_Save.Size = new System.Drawing.Size(98, 54);
            this.btnNV_Save.TabIndex = 9;
            this.btnNV_Save.Text = "Lưu";
            this.btnNV_Save.UseVisualStyleBackColor = true;
            this.btnNV_Save.Click += new System.EventHandler(this.btnNV_Save_Click);
            // 
            // btnNV_Del
            // 
            this.btnNV_Del.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNV_Del.Location = new System.Drawing.Point(637, 155);
            this.btnNV_Del.Name = "btnNV_Del";
            this.btnNV_Del.Size = new System.Drawing.Size(98, 54);
            this.btnNV_Del.TabIndex = 8;
            this.btnNV_Del.Text = "Xóa \r\nnhân viên";
            this.btnNV_Del.UseVisualStyleBackColor = true;
            this.btnNV_Del.Click += new System.EventHandler(this.btnNV_Del_Click);
            // 
            // btnNV_Update
            // 
            this.btnNV_Update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNV_Update.Location = new System.Drawing.Point(503, 155);
            this.btnNV_Update.Name = "btnNV_Update";
            this.btnNV_Update.Size = new System.Drawing.Size(98, 54);
            this.btnNV_Update.TabIndex = 7;
            this.btnNV_Update.Text = "Cập nhật nhân viên";
            this.btnNV_Update.UseVisualStyleBackColor = true;
            this.btnNV_Update.Click += new System.EventHandler(this.btnNV_Update_Click);
            // 
            // btnNV_Insert
            // 
            this.btnNV_Insert.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNV_Insert.Location = new System.Drawing.Point(370, 155);
            this.btnNV_Insert.Name = "btnNV_Insert";
            this.btnNV_Insert.Size = new System.Drawing.Size(98, 54);
            this.btnNV_Insert.TabIndex = 6;
            this.btnNV_Insert.Text = "Thêm nhân viên";
            this.btnNV_Insert.UseVisualStyleBackColor = true;
            this.btnNV_Insert.Click += new System.EventHandler(this.btnNV_Insert_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(557, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "CMND";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Địa chỉ";
            // 
            // txtNV_CMND
            // 
            this.txtNV_CMND.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNV_CMND.Enabled = false;
            this.txtNV_CMND.Location = new System.Drawing.Point(622, 97);
            this.txtNV_CMND.Name = "txtNV_CMND";
            this.txtNV_CMND.Size = new System.Drawing.Size(218, 27);
            this.txtNV_CMND.TabIndex = 4;
            this.txtNV_CMND.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_CMND_KeyPress);
            // 
            // txtNV_DC
            // 
            this.txtNV_DC.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNV_DC.Enabled = false;
            this.txtNV_DC.Location = new System.Drawing.Point(145, 97);
            this.txtNV_DC.Name = "txtNV_DC";
            this.txtNV_DC.Size = new System.Drawing.Size(350, 27);
            this.txtNV_DC.TabIndex = 3;
            this.txtNV_DC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_DC_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(547, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Chức vụ";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ngày vào làm";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(80, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Họ tên";
            // 
            // txtNV_HoTen
            // 
            this.txtNV_HoTen.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNV_HoTen.Enabled = false;
            this.txtNV_HoTen.Location = new System.Drawing.Point(145, 44);
            this.txtNV_HoTen.Name = "txtNV_HoTen";
            this.txtNV_HoTen.Size = new System.Drawing.Size(350, 27);
            this.txtNV_HoTen.TabIndex = 0;
            this.txtNV_HoTen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_HoTen_KeyPress);
            // 
            // txtGetIDNV
            // 
            this.txtGetIDNV.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtGetIDNV.Location = new System.Drawing.Point(355, 449);
            this.txtGetIDNV.Name = "txtGetIDNV";
            this.txtGetIDNV.Size = new System.Drawing.Size(39, 27);
            this.txtGetIDNV.TabIndex = 10;
            this.txtGetIDNV.TabStop = false;
            // 
            // tabQLTK
            // 
            this.tabQLTK.Controls.Add(this.panel2);
            this.tabQLTK.Controls.Add(this.dgvTK);
            this.tabQLTK.Controls.Add(this.txtGetIDTK);
            this.tabQLTK.Location = new System.Drawing.Point(4, 29);
            this.tabQLTK.Name = "tabQLTK";
            this.tabQLTK.Size = new System.Drawing.Size(933, 484);
            this.tabQLTK.TabIndex = 2;
            this.tabQLTK.Text = "Quản lý tài khoản";
            this.tabQLTK.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnTK_Save);
            this.panel2.Controls.Add(this.btnTK_Update);
            this.panel2.Controls.Add(this.txtTK_MK);
            this.panel2.Controls.Add(this.txtTK_TenDN);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(933, 227);
            this.panel2.TabIndex = 1;
            // 
            // btnTK_Save
            // 
            this.btnTK_Save.Enabled = false;
            this.btnTK_Save.Location = new System.Drawing.Point(500, 129);
            this.btnTK_Save.Name = "btnTK_Save";
            this.btnTK_Save.Size = new System.Drawing.Size(97, 52);
            this.btnTK_Save.TabIndex = 3;
            this.btnTK_Save.Text = "Lưu";
            this.btnTK_Save.UseVisualStyleBackColor = true;
            this.btnTK_Save.Click += new System.EventHandler(this.btnTK_Save_Click);
            // 
            // btnTK_Update
            // 
            this.btnTK_Update.Location = new System.Drawing.Point(349, 129);
            this.btnTK_Update.Name = "btnTK_Update";
            this.btnTK_Update.Size = new System.Drawing.Size(97, 52);
            this.btnTK_Update.TabIndex = 2;
            this.btnTK_Update.Text = "Cập nhật";
            this.btnTK_Update.UseVisualStyleBackColor = true;
            this.btnTK_Update.Click += new System.EventHandler(this.btnTK_Update_Click);
            // 
            // txtTK_MK
            // 
            this.txtTK_MK.Enabled = false;
            this.txtTK_MK.Location = new System.Drawing.Point(599, 53);
            this.txtTK_MK.Name = "txtTK_MK";
            this.txtTK_MK.Size = new System.Drawing.Size(248, 27);
            this.txtTK_MK.TabIndex = 1;
            this.txtTK_MK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTK_TenDN_KeyPress);
            // 
            // txtTK_TenDN
            // 
            this.txtTK_TenDN.Enabled = false;
            this.txtTK_TenDN.Location = new System.Drawing.Point(192, 53);
            this.txtTK_TenDN.Name = "txtTK_TenDN";
            this.txtTK_TenDN.Size = new System.Drawing.Size(259, 27);
            this.txtTK_TenDN.TabIndex = 0;
            this.txtTK_TenDN.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTK_TenDN_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(516, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mật khẩu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(67, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Tên đăng nhập";
            // 
            // dgvTK
            // 
            this.dgvTK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvTK.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTK.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvTK.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvTK.Location = new System.Drawing.Point(0, 233);
            this.dgvTK.MultiSelect = false;
            this.dgvTK.Name = "dgvTK";
            this.dgvTK.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTK.Size = new System.Drawing.Size(933, 251);
            this.dgvTK.TabIndex = 0;
            this.dgvTK.TabStop = false;
            // 
            // txtGetIDTK
            // 
            this.txtGetIDTK.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtGetIDTK.Location = new System.Drawing.Point(398, 449);
            this.txtGetIDTK.Name = "txtGetIDTK";
            this.txtGetIDTK.Size = new System.Drawing.Size(100, 27);
            this.txtGetIDTK.TabIndex = 4;
            this.txtGetIDTK.TabStop = false;
            // 
            // tabQLDV
            // 
            this.tabQLDV.Controls.Add(this.panel3);
            this.tabQLDV.Controls.Add(this.dgvQLDV);
            this.tabQLDV.Controls.Add(this.txtGetIDDV_QL);
            this.tabQLDV.Location = new System.Drawing.Point(4, 29);
            this.tabQLDV.Name = "tabQLDV";
            this.tabQLDV.Padding = new System.Windows.Forms.Padding(3);
            this.tabQLDV.Size = new System.Drawing.Size(933, 484);
            this.tabQLDV.TabIndex = 1;
            this.tabQLDV.Text = "Quản lý dịch vụ";
            this.tabQLDV.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnDV_Save);
            this.panel3.Controls.Add(this.btnDV_Del);
            this.panel3.Controls.Add(this.btnDV_Update);
            this.panel3.Controls.Add(this.btnDV_Insert);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtDV_GiaDV);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.txtDV_TenDV);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(927, 237);
            this.panel3.TabIndex = 1;
            // 
            // btnDV_Save
            // 
            this.btnDV_Save.Enabled = false;
            this.btnDV_Save.Location = new System.Drawing.Point(624, 133);
            this.btnDV_Save.Name = "btnDV_Save";
            this.btnDV_Save.Size = new System.Drawing.Size(91, 55);
            this.btnDV_Save.TabIndex = 5;
            this.btnDV_Save.Text = "Lưu";
            this.btnDV_Save.UseVisualStyleBackColor = true;
            this.btnDV_Save.Click += new System.EventHandler(this.btnDV_Save_Click);
            // 
            // btnDV_Del
            // 
            this.btnDV_Del.Location = new System.Drawing.Point(485, 133);
            this.btnDV_Del.Name = "btnDV_Del";
            this.btnDV_Del.Size = new System.Drawing.Size(91, 55);
            this.btnDV_Del.TabIndex = 4;
            this.btnDV_Del.Text = "Xóa dịch vụ";
            this.btnDV_Del.UseVisualStyleBackColor = true;
            this.btnDV_Del.Click += new System.EventHandler(this.btnDV_Del_Click);
            // 
            // btnDV_Update
            // 
            this.btnDV_Update.Location = new System.Drawing.Point(348, 133);
            this.btnDV_Update.Name = "btnDV_Update";
            this.btnDV_Update.Size = new System.Drawing.Size(91, 55);
            this.btnDV_Update.TabIndex = 3;
            this.btnDV_Update.Text = "Cập nhật dịch vụ";
            this.btnDV_Update.UseVisualStyleBackColor = true;
            this.btnDV_Update.Click += new System.EventHandler(this.btnDV_Update_Click);
            // 
            // btnDV_Insert
            // 
            this.btnDV_Insert.Location = new System.Drawing.Point(214, 133);
            this.btnDV_Insert.Name = "btnDV_Insert";
            this.btnDV_Insert.Size = new System.Drawing.Size(91, 55);
            this.btnDV_Insert.TabIndex = 2;
            this.btnDV_Insert.Text = "Thêm dịch vụ";
            this.btnDV_Insert.UseVisualStyleBackColor = true;
            this.btnDV_Insert.Click += new System.EventHandler(this.btnDV_Insert_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(539, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 20);
            this.label9.TabIndex = 1;
            this.label9.Text = "Giá dịch vụ";
            // 
            // txtDV_GiaDV
            // 
            this.txtDV_GiaDV.Enabled = false;
            this.txtDV_GiaDV.Location = new System.Drawing.Point(658, 57);
            this.txtDV_GiaDV.Name = "txtDV_GiaDV";
            this.txtDV_GiaDV.Size = new System.Drawing.Size(158, 27);
            this.txtDV_GiaDV.TabIndex = 1;
            this.txtDV_GiaDV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDV_GiaDV_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(113, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Tên dịch vụ";
            // 
            // txtDV_TenDV
            // 
            this.txtDV_TenDV.Enabled = false;
            this.txtDV_TenDV.Location = new System.Drawing.Point(232, 57);
            this.txtDV_TenDV.Name = "txtDV_TenDV";
            this.txtDV_TenDV.Size = new System.Drawing.Size(276, 27);
            this.txtDV_TenDV.TabIndex = 0;
            this.txtDV_TenDV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_HoTen_KeyPress);
            // 
            // dgvQLDV
            // 
            this.dgvQLDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvQLDV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvQLDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQLDV.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvQLDV.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvQLDV.Location = new System.Drawing.Point(3, 246);
            this.dgvQLDV.MultiSelect = false;
            this.dgvQLDV.Name = "dgvQLDV";
            this.dgvQLDV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvQLDV.Size = new System.Drawing.Size(927, 235);
            this.dgvQLDV.TabIndex = 0;
            this.dgvQLDV.TabStop = false;
            // 
            // txtGetIDDV_QL
            // 
            this.txtGetIDDV_QL.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtGetIDDV_QL.Enabled = false;
            this.txtGetIDDV_QL.Location = new System.Drawing.Point(438, 449);
            this.txtGetIDDV_QL.Name = "txtGetIDDV_QL";
            this.txtGetIDDV_QL.Size = new System.Drawing.Size(73, 27);
            this.txtGetIDDV_QL.TabIndex = 0;
            this.txtGetIDDV_QL.TabStop = false;
            // 
            // tabQLPH
            // 
            this.tabQLPH.Controls.Add(this.panel4);
            this.tabQLPH.Controls.Add(this.dgvPH);
            this.tabQLPH.Controls.Add(this.txtGetIDLP);
            this.tabQLPH.Controls.Add(this.txtGetIDPH);
            this.tabQLPH.Location = new System.Drawing.Point(4, 29);
            this.tabQLPH.Name = "tabQLPH";
            this.tabQLPH.Size = new System.Drawing.Size(933, 484);
            this.tabQLPH.TabIndex = 3;
            this.tabQLPH.Text = "Quản lý phòng";
            this.tabQLPH.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.grLP);
            this.panel4.Controls.Add(this.btnPH_DisplayLPH);
            this.panel4.Controls.Add(this.btnPH_DisplayPH);
            this.panel4.Controls.Add(this.btnPH_Save);
            this.panel4.Controls.Add(this.btnPH_Del);
            this.panel4.Controls.Add(this.btnPH_Update);
            this.panel4.Controls.Add(this.btnPH_Insert);
            this.panel4.Controls.Add(this.grPhong);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(933, 273);
            this.panel4.TabIndex = 1;
            // 
            // grLP
            // 
            this.grLP.Controls.Add(this.txtLP_LoaiPH);
            this.grLP.Controls.Add(this.txtLP_Gia);
            this.grLP.Controls.Add(this.label13);
            this.grLP.Controls.Add(this.label15);
            this.grLP.Enabled = false;
            this.grLP.Location = new System.Drawing.Point(552, 19);
            this.grLP.Name = "grLP";
            this.grLP.Size = new System.Drawing.Size(313, 134);
            this.grLP.TabIndex = 4;
            this.grLP.TabStop = false;
            this.grLP.Text = "Loại phòng";
            // 
            // txtLP_LoaiPH
            // 
            this.txtLP_LoaiPH.Enabled = false;
            this.txtLP_LoaiPH.Location = new System.Drawing.Point(147, 37);
            this.txtLP_LoaiPH.Name = "txtLP_LoaiPH";
            this.txtLP_LoaiPH.Size = new System.Drawing.Size(136, 27);
            this.txtLP_LoaiPH.TabIndex = 1;
            this.txtLP_LoaiPH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_DC_KeyPress);
            // 
            // txtLP_Gia
            // 
            this.txtLP_Gia.Enabled = false;
            this.txtLP_Gia.Location = new System.Drawing.Point(147, 86);
            this.txtLP_Gia.Name = "txtLP_Gia";
            this.txtLP_Gia.Size = new System.Drawing.Size(136, 27);
            this.txtLP_Gia.TabIndex = 1;
            this.txtLP_Gia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDV_GiaDV_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(36, 40);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "Loại phòng";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(36, 89);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Giá";
            // 
            // btnPH_DisplayLPH
            // 
            this.btnPH_DisplayLPH.Location = new System.Drawing.Point(642, 178);
            this.btnPH_DisplayLPH.Name = "btnPH_DisplayLPH";
            this.btnPH_DisplayLPH.Size = new System.Drawing.Size(145, 48);
            this.btnPH_DisplayLPH.TabIndex = 4;
            this.btnPH_DisplayLPH.Text = "Xem loại phòng";
            this.btnPH_DisplayLPH.UseVisualStyleBackColor = true;
            this.btnPH_DisplayLPH.Click += new System.EventHandler(this.btnPH_DisplayLPH_Click);
            // 
            // btnPH_DisplayPH
            // 
            this.btnPH_DisplayPH.Enabled = false;
            this.btnPH_DisplayPH.Location = new System.Drawing.Point(165, 217);
            this.btnPH_DisplayPH.Name = "btnPH_DisplayPH";
            this.btnPH_DisplayPH.Size = new System.Drawing.Size(118, 42);
            this.btnPH_DisplayPH.TabIndex = 4;
            this.btnPH_DisplayPH.Text = "Xem phòng";
            this.btnPH_DisplayPH.UseVisualStyleBackColor = true;
            this.btnPH_DisplayPH.Click += new System.EventHandler(this.btnPH_DisplayPH_Click);
            // 
            // btnPH_Save
            // 
            this.btnPH_Save.Enabled = false;
            this.btnPH_Save.Location = new System.Drawing.Point(420, 217);
            this.btnPH_Save.Name = "btnPH_Save";
            this.btnPH_Save.Size = new System.Drawing.Size(88, 42);
            this.btnPH_Save.TabIndex = 4;
            this.btnPH_Save.Text = "Lưu";
            this.btnPH_Save.UseVisualStyleBackColor = true;
            this.btnPH_Save.Click += new System.EventHandler(this.btnPH_Save_Click);
            // 
            // btnPH_Del
            // 
            this.btnPH_Del.Location = new System.Drawing.Point(420, 156);
            this.btnPH_Del.Name = "btnPH_Del";
            this.btnPH_Del.Size = new System.Drawing.Size(88, 42);
            this.btnPH_Del.TabIndex = 4;
            this.btnPH_Del.Text = "Xóa";
            this.btnPH_Del.UseVisualStyleBackColor = true;
            this.btnPH_Del.Click += new System.EventHandler(this.btnPH_Del_Click);
            // 
            // btnPH_Update
            // 
            this.btnPH_Update.Location = new System.Drawing.Point(420, 96);
            this.btnPH_Update.Name = "btnPH_Update";
            this.btnPH_Update.Size = new System.Drawing.Size(88, 42);
            this.btnPH_Update.TabIndex = 4;
            this.btnPH_Update.Text = "Cập nhật";
            this.btnPH_Update.UseVisualStyleBackColor = true;
            this.btnPH_Update.Click += new System.EventHandler(this.btnPH_Update_Click);
            // 
            // btnPH_Insert
            // 
            this.btnPH_Insert.Location = new System.Drawing.Point(420, 35);
            this.btnPH_Insert.Name = "btnPH_Insert";
            this.btnPH_Insert.Size = new System.Drawing.Size(88, 42);
            this.btnPH_Insert.TabIndex = 4;
            this.btnPH_Insert.Text = "Thêm";
            this.btnPH_Insert.UseVisualStyleBackColor = true;
            this.btnPH_Insert.Click += new System.EventHandler(this.btnPH_Insert_Click);
            // 
            // grPhong
            // 
            this.grPhong.Controls.Add(this.cbPH_LP);
            this.grPhong.Controls.Add(this.cbPH_TT);
            this.grPhong.Controls.Add(this.txtPH_SoPH);
            this.grPhong.Controls.Add(this.label12);
            this.grPhong.Controls.Add(this.label11);
            this.grPhong.Controls.Add(this.label10);
            this.grPhong.Location = new System.Drawing.Point(64, 19);
            this.grPhong.Name = "grPhong";
            this.grPhong.Size = new System.Drawing.Size(313, 184);
            this.grPhong.TabIndex = 3;
            this.grPhong.TabStop = false;
            this.grPhong.Text = "Phòng";
            // 
            // cbPH_LP
            // 
            this.cbPH_LP.Enabled = false;
            this.cbPH_LP.FormattingEnabled = true;
            this.cbPH_LP.Location = new System.Drawing.Point(142, 85);
            this.cbPH_LP.Name = "cbPH_LP";
            this.cbPH_LP.Size = new System.Drawing.Size(136, 28);
            this.cbPH_LP.TabIndex = 2;
            this.cbPH_LP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbNV_ChucVu_KeyPress);
            // 
            // cbPH_TT
            // 
            this.cbPH_TT.Enabled = false;
            this.cbPH_TT.FormattingEnabled = true;
            this.cbPH_TT.Items.AddRange(new object[] {
            "Trống",
            "Thuê"});
            this.cbPH_TT.Location = new System.Drawing.Point(142, 134);
            this.cbPH_TT.Name = "cbPH_TT";
            this.cbPH_TT.Size = new System.Drawing.Size(136, 28);
            this.cbPH_TT.TabIndex = 2;
            this.cbPH_TT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbNV_ChucVu_KeyPress);
            // 
            // txtPH_SoPH
            // 
            this.txtPH_SoPH.Enabled = false;
            this.txtPH_SoPH.Location = new System.Drawing.Point(142, 37);
            this.txtPH_SoPH.Name = "txtPH_SoPH";
            this.txtPH_SoPH.Size = new System.Drawing.Size(136, 27);
            this.txtPH_SoPH.TabIndex = 1;
            this.txtPH_SoPH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNV_CMND_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(31, 88);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Loại phòng";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Tình trạng";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Số phòng";
            // 
            // dgvPH
            // 
            this.dgvPH.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvPH.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPH.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvPH.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvPH.Location = new System.Drawing.Point(0, 279);
            this.dgvPH.Name = "dgvPH";
            this.dgvPH.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPH.Size = new System.Drawing.Size(933, 205);
            this.dgvPH.TabIndex = 0;
            this.dgvPH.TabStop = false;
            // 
            // txtGetIDLP
            // 
            this.txtGetIDLP.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtGetIDLP.Enabled = false;
            this.txtGetIDLP.Location = new System.Drawing.Point(501, 449);
            this.txtGetIDLP.Name = "txtGetIDLP";
            this.txtGetIDLP.Size = new System.Drawing.Size(49, 27);
            this.txtGetIDLP.TabIndex = 1;
            this.txtGetIDLP.TabStop = false;
            // 
            // txtGetIDPH
            // 
            this.txtGetIDPH.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.txtGetIDPH.Enabled = false;
            this.txtGetIDPH.Location = new System.Drawing.Point(446, 449);
            this.txtGetIDPH.Name = "txtGetIDPH";
            this.txtGetIDPH.Size = new System.Drawing.Size(49, 27);
            this.txtGetIDPH.TabIndex = 1;
            this.txtGetIDPH.TabStop = false;
            // 
            // MainManager_QLKS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 517);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "MainManager_QLKS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Khách Sạn";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainManager_QLKS_FormClosed);
            this.Load += new System.EventHandler(this.MainManager_QLKS_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabQLNV.ResumeLayout(false);
            this.tabQLNV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_QLNV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabQLTK.ResumeLayout(false);
            this.tabQLTK.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTK)).EndInit();
            this.tabQLDV.ResumeLayout(false);
            this.tabQLDV.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQLDV)).EndInit();
            this.tabQLPH.ResumeLayout(false);
            this.tabQLPH.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.grLP.ResumeLayout(false);
            this.grLP.PerformLayout();
            this.grPhong.ResumeLayout(false);
            this.grPhong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPH)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabQLNV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNV_HoTen;
        private System.Windows.Forms.TabPage tabQLDV;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNV_CMND;
        private System.Windows.Forms.TextBox txtNV_DC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgv_QLNV;
        private System.Windows.Forms.Button btnNV_Save;
        private System.Windows.Forms.Button btnNV_Del;
        private System.Windows.Forms.Button btnNV_Update;
        private System.Windows.Forms.Button btnNV_Insert;
        private System.Windows.Forms.TabPage tabQLTK;
        private System.Windows.Forms.DateTimePicker dtpNV_NVL;
        private System.Windows.Forms.ComboBox cbNV_ChucVu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtGetIDNV;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnTK_Save;
        private System.Windows.Forms.Button btnTK_Update;
        private System.Windows.Forms.TextBox txtTK_MK;
        private System.Windows.Forms.TextBox txtTK_TenDN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvTK;
        private System.Windows.Forms.TextBox txtGetIDTK;
        private System.Windows.Forms.TabPage tabQLPH;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnDV_Save;
        private System.Windows.Forms.Button btnDV_Del;
        private System.Windows.Forms.Button btnDV_Update;
        private System.Windows.Forms.Button btnDV_Insert;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDV_GiaDV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDV_TenDV;
        private System.Windows.Forms.DataGridView dgvQLDV;
        private System.Windows.Forms.TextBox txtGetIDDV_QL;
        private System.Windows.Forms.DataGridView dgvPH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox grPhong;
        private System.Windows.Forms.ComboBox cbPH_TT;
        private System.Windows.Forms.TextBox txtPH_SoPH;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox grLP;
        private System.Windows.Forms.TextBox txtLP_Gia;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnPH_Del;
        private System.Windows.Forms.Button btnPH_Update;
        private System.Windows.Forms.Button btnPH_Insert;
        private System.Windows.Forms.ComboBox cbPH_LP;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnPH_Save;
        private System.Windows.Forms.Button btnPH_DisplayLPH;
        private System.Windows.Forms.Button btnPH_DisplayPH;
        private System.Windows.Forms.TextBox txtGetIDLP;
        private System.Windows.Forms.TextBox txtGetIDPH;
        private System.Windows.Forms.TextBox txtLP_LoaiPH;
    }
}