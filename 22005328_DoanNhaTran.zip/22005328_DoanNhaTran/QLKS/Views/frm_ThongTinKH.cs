﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLKS.Controller;
using System.Data.SqlClient;

namespace QLKS.Views
{
    public partial class frm_ThongTinKH : Form
    {
        private int MaKH;
        public frm_ThongTinKH()
        {
            InitializeComponent();
        }
        public frm_ThongTinKH(int MaKH)
        {
            this.MaKH = MaKH;
            InitializeComponent();
        }

        clsKH kh = new clsKH();

        private void btnTTKH_Save_Click(object sender, EventArgs e)
        {
            if(this.Text == "Thêm khách hàng")
            {
                if (txtTTKH_Hoten.TextLength > 100)
                {
                    MessageBox.Show("Họ tên không được quá 100 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_Hoten.Focus();
                }
                else if(txtTTKH_Hoten.TextLength == 0)
                {
                    MessageBox.Show("Họ tên không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_Hoten.Focus();
                }
                else if (txtTTKH_SDT.TextLength < 9 || txtTTKH_SDT.TextLength >10)
                {
                    MessageBox.Show("Số điện thoại phải đủ 10 số!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_SDT.Focus();
                }
                else if (txtTTKH_DC.TextLength > 150)
                {
                    MessageBox.Show("Địa chỉ không được quá 150 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_DC.Focus();
                }
                else if (txtTTKH_CMND.TextLength < 11 ||txtTTKH_CMND.TextLength >12)
                {
                    MessageBox.Show("Số điện thoại phải đủ 10 số!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_SDT.Focus();
                }
                else
                {
                    int rec = kh.Insert_KH(txtTTKH_Hoten.Text, txtTTKH_CMND.Text, txtTTKH_DC.Text, txtTTKH_SDT.Text);
                    if (rec > 0)
                    {
                        DialogResult tb = MessageBox.Show("Thêm thành công!\nNhập thêm khách hàng?", "Thông báo!", MessageBoxButtons.YesNo);
                        if (tb == DialogResult.Yes)
                        {
                            txtTTKH_CMND.Clear();
                            txtTTKH_DC.Clear();
                            txtTTKH_Hoten.Clear();
                            txtTTKH_SDT.Clear();

                        }
                        else this.Close();
                    }
                    else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
                }
            }
            else if(this.Text == "Cập nhật khách hàng")
            {
                if (txtTTKH_Hoten.TextLength > 100)
                {
                    MessageBox.Show("Họ tên không được quá 100 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_Hoten.Focus();
                }
                else if (txtTTKH_Hoten.TextLength == 0)
                {
                    MessageBox.Show("Họ tên không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_Hoten.Focus();
                }
                else if (txtTTKH_SDT.TextLength < 9 || txtTTKH_SDT.TextLength > 10)
                {
                    MessageBox.Show("Số điện thoại phải đủ 10 số!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_SDT.Focus();
                }
                else if (txtTTKH_SDT.TextLength > 10)
                {
                    MessageBox.Show("Số điện thoại không được quá 10 số!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_SDT.Focus();
                }
                else if (txtTTKH_DC.TextLength > 150)
                {
                    MessageBox.Show("Địa chỉ không được quá 150 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_DC.Focus();
                }
                else if (txtTTKH_CMND.TextLength < 11 || txtTTKH_CMND.TextLength > 12)
                {
                    MessageBox.Show("Số điện thoại phải đủ 10 số!", "Thông báo!", MessageBoxButtons.OK);
                    txtTTKH_SDT.Focus();
                }
                else
                {
                    int rec = kh.Update_KH(MaKH, txtTTKH_Hoten.Text, txtTTKH_CMND.Text, txtTTKH_DC.Text, txtTTKH_SDT.Text);
                    if (rec > 0)
                    {
                        DialogResult tb = MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);
                        this.Close();
                    }
                    else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
                }
            }
            
        }

        void BindingDataKH()
        {
            txtTTKH_CMND.DataBindings.Clear();
            txtTTKH_DC.DataBindings.Clear();
            txtTTKH_Hoten.DataBindings.Clear();
            txtTTKH_SDT.DataBindings.Clear();

            txtTTKH_CMND.DataBindings.Add("Text", dgvTTKH.DataSource, "CMND");
            txtTTKH_DC.DataBindings.Add("Text", dgvTTKH.DataSource, "DiaChi");
            txtTTKH_Hoten.DataBindings.Add("Text", dgvTTKH.DataSource, "HoTen");
            txtTTKH_SDT.DataBindings.Add("Text", dgvTTKH.DataSource, "SDT");
        }

        void loadDGV_KH()
        {
            dgvTTKH.DataSource = kh.GetTTKH(MaKH);

            BindingDataKH();
        }

        private void frm_ThongTinKH_Load(object sender, EventArgs e)
        {
            loadDGV_KH();
        }

        #region KeyPressHandle
        private void txtTTKH_Hoten_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar)) e.Handled = true;
        }

        private void txtTTKH_SDT_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsWhiteSpace(e.KeyChar)) e.Handled = true;
        }

        private void txtTTKH_DC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsHighSurrogate(e.KeyChar) || char.IsLowSurrogate(e.KeyChar)) e.Handled = true;
        }

        private void txtTTKH_CMND_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsWhiteSpace(e.KeyChar)) e.Handled = true;
        }
        #endregion
    }
}
