﻿
namespace QLKS
{
    partial class Main_QLKS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPhong = new System.Windows.Forms.TabPage();
            this.panelVTP = new System.Windows.Forms.Panel();
            this.cbVTP_TenVT = new System.Windows.Forms.ComboBox();
            this.txtVTP_SoLuong = new System.Windows.Forms.TextBox();
            this.btnVTP_TurnBack = new System.Windows.Forms.Button();
            this.btnVTP_Save = new System.Windows.Forms.Button();
            this.btnVTP_Del = new System.Windows.Forms.Button();
            this.btnVTP_Insert = new System.Windows.Forms.Button();
            this.btnVTP_Update = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtGetIDVT = new System.Windows.Forms.TextBox();
            this.txtGetIDphong = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbTTP = new System.Windows.Forms.ComboBox();
            this.btnTTP_Save = new System.Windows.Forms.Button();
            this.btnPhong_Update = new System.Windows.Forms.Button();
            this.btn_VTP = new System.Windows.Forms.Button();
            this.tabKHvaTP = new System.Windows.Forms.TabPage();
            this.dgv_KhachHang = new System.Windows.Forms.DataGridView();
            this.panelTP = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnNT_update = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnNT_Save = new System.Windows.Forms.Button();
            this.dtpTP_NgayTra = new System.Windows.Forms.DateTimePicker();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbTP_SoPH = new System.Windows.Forms.ComboBox();
            this.btnTP_Insert = new System.Windows.Forms.Button();
            this.btnTP_Save = new System.Windows.Forms.Button();
            this.btnTP_update = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpTP_NgayDuKien = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpTP_NgayThue = new System.Windows.Forms.DateTimePicker();
            this.btnTP_TurnBack = new System.Windows.Forms.Button();
            this.btnTTKH_Update = new System.Windows.Forms.Button();
            this.btnTP = new System.Windows.Forms.Button();
            this.btnKH_insert = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtGetIDPH = new System.Windows.Forms.TextBox();
            this.txtGetIDMaTP = new System.Windows.Forms.TextBox();
            this.txtGetIDKH = new System.Windows.Forms.TextBox();
            this.tabDV = new System.Windows.Forms.TabPage();
            this.dgv_DV = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtGetIDDV = new System.Windows.Forms.TextBox();
            this.txtGetIDPDV = new System.Windows.Forms.TextBox();
            this.txtGetIDKH_DV = new System.Windows.Forms.TextBox();
            this.btnDV_Update = new System.Windows.Forms.Button();
            this.btnDV_Save = new System.Windows.Forms.Button();
            this.btnDV_Del = new System.Windows.Forms.Button();
            this.btnDV_Insert = new System.Windows.Forms.Button();
            this.txtDV_SoLuong = new System.Windows.Forms.TextBox();
            this.cbDV_TenDV = new System.Windows.Forms.ComboBox();
            this.cbDV_CMND = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPhong.SuspendLayout();
            this.panelVTP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabKHvaTP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_KhachHang)).BeginInit();
            this.panelTP.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabDV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DV)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPhong);
            this.tabControl1.Controls.Add(this.tabKHvaTP);
            this.tabControl1.Controls.Add(this.tabDV);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1088, 583);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPhong
            // 
            this.tabPhong.Controls.Add(this.panelVTP);
            this.tabPhong.Controls.Add(this.dgvPhong);
            this.tabPhong.Controls.Add(this.panel2);
            this.tabPhong.Controls.Add(this.groupBox1);
            this.tabPhong.Controls.Add(this.btn_VTP);
            this.tabPhong.Location = new System.Drawing.Point(4, 29);
            this.tabPhong.Name = "tabPhong";
            this.tabPhong.Padding = new System.Windows.Forms.Padding(3);
            this.tabPhong.Size = new System.Drawing.Size(1080, 550);
            this.tabPhong.TabIndex = 0;
            this.tabPhong.Text = "Phòng & vật tư";
            this.tabPhong.UseVisualStyleBackColor = true;
            // 
            // panelVTP
            // 
            this.panelVTP.Controls.Add(this.cbVTP_TenVT);
            this.panelVTP.Controls.Add(this.txtVTP_SoLuong);
            this.panelVTP.Controls.Add(this.btnVTP_TurnBack);
            this.panelVTP.Controls.Add(this.btnVTP_Save);
            this.panelVTP.Controls.Add(this.btnVTP_Del);
            this.panelVTP.Controls.Add(this.btnVTP_Insert);
            this.panelVTP.Controls.Add(this.btnVTP_Update);
            this.panelVTP.Controls.Add(this.label5);
            this.panelVTP.Controls.Add(this.label4);
            this.panelVTP.Location = new System.Drawing.Point(690, 39);
            this.panelVTP.Name = "panelVTP";
            this.panelVTP.Size = new System.Drawing.Size(306, 432);
            this.panelVTP.TabIndex = 6;
            this.panelVTP.Visible = false;
            // 
            // cbVTP_TenVT
            // 
            this.cbVTP_TenVT.Enabled = false;
            this.cbVTP_TenVT.FormattingEnabled = true;
            this.cbVTP_TenVT.Items.AddRange(new object[] {
            "Khăn tắm",
            "Dầu gội",
            "Sữa tắm ",
            "Móc treo đồ",
            "Kem đánh răng"});
            this.cbVTP_TenVT.Location = new System.Drawing.Point(128, 56);
            this.cbVTP_TenVT.Name = "cbVTP_TenVT";
            this.cbVTP_TenVT.Size = new System.Drawing.Size(161, 28);
            this.cbVTP_TenVT.TabIndex = 6;
            this.cbVTP_TenVT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbVTP_TenVT_KeyPress);
            // 
            // txtVTP_SoLuong
            // 
            this.txtVTP_SoLuong.Enabled = false;
            this.txtVTP_SoLuong.Location = new System.Drawing.Point(128, 100);
            this.txtVTP_SoLuong.Name = "txtVTP_SoLuong";
            this.txtVTP_SoLuong.Size = new System.Drawing.Size(100, 27);
            this.txtVTP_SoLuong.TabIndex = 1;
            this.txtVTP_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVTP_SoLuong_KeyPress);
            // 
            // btnVTP_TurnBack
            // 
            this.btnVTP_TurnBack.Location = new System.Drawing.Point(102, 346);
            this.btnVTP_TurnBack.Name = "btnVTP_TurnBack";
            this.btnVTP_TurnBack.Size = new System.Drawing.Size(102, 44);
            this.btnVTP_TurnBack.TabIndex = 5;
            this.btnVTP_TurnBack.Text = "Trở về";
            this.btnVTP_TurnBack.UseVisualStyleBackColor = true;
            this.btnVTP_TurnBack.Click += new System.EventHandler(this.btnVTP_TurnBack_Click);
            // 
            // btnVTP_Save
            // 
            this.btnVTP_Save.Location = new System.Drawing.Point(170, 250);
            this.btnVTP_Save.Name = "btnVTP_Save";
            this.btnVTP_Save.Size = new System.Drawing.Size(102, 62);
            this.btnVTP_Save.TabIndex = 5;
            this.btnVTP_Save.Text = "Lưu";
            this.btnVTP_Save.UseVisualStyleBackColor = true;
            this.btnVTP_Save.Visible = false;
            this.btnVTP_Save.Click += new System.EventHandler(this.btnVTP_Save_Click);
            // 
            // btnVTP_Del
            // 
            this.btnVTP_Del.Location = new System.Drawing.Point(35, 250);
            this.btnVTP_Del.Name = "btnVTP_Del";
            this.btnVTP_Del.Size = new System.Drawing.Size(102, 62);
            this.btnVTP_Del.TabIndex = 5;
            this.btnVTP_Del.Text = "Xóa vật tư";
            this.btnVTP_Del.UseVisualStyleBackColor = true;
            this.btnVTP_Del.Click += new System.EventHandler(this.btnVTP_Del_Click);
            // 
            // btnVTP_Insert
            // 
            this.btnVTP_Insert.Location = new System.Drawing.Point(35, 161);
            this.btnVTP_Insert.Name = "btnVTP_Insert";
            this.btnVTP_Insert.Size = new System.Drawing.Size(102, 62);
            this.btnVTP_Insert.TabIndex = 5;
            this.btnVTP_Insert.Text = "Thêm vật tư";
            this.btnVTP_Insert.UseVisualStyleBackColor = true;
            this.btnVTP_Insert.Click += new System.EventHandler(this.btnVTP_Insert_Click);
            // 
            // btnVTP_Update
            // 
            this.btnVTP_Update.Location = new System.Drawing.Point(170, 161);
            this.btnVTP_Update.Name = "btnVTP_Update";
            this.btnVTP_Update.Size = new System.Drawing.Size(102, 62);
            this.btnVTP_Update.TabIndex = 5;
            this.btnVTP_Update.Text = "Cập nhật\r\nsố lượng";
            this.btnVTP_Update.UseVisualStyleBackColor = true;
            this.btnVTP_Update.Click += new System.EventHandler(this.btnVTP_Update_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Tên vật tư";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Số lượng";
            // 
            // dgvPhong
            // 
            this.dgvPhong.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvPhong.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(39, 39);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhong.Size = new System.Drawing.Size(641, 476);
            this.dgvPhong.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtGetIDVT);
            this.panel2.Controls.Add(this.txtGetIDphong);
            this.panel2.Location = new System.Drawing.Point(77, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(141, 54);
            this.panel2.TabIndex = 8;
            // 
            // txtGetIDVT
            // 
            this.txtGetIDVT.Location = new System.Drawing.Point(77, 16);
            this.txtGetIDVT.Name = "txtGetIDVT";
            this.txtGetIDVT.Size = new System.Drawing.Size(46, 27);
            this.txtGetIDVT.TabIndex = 7;
            // 
            // txtGetIDphong
            // 
            this.txtGetIDphong.Location = new System.Drawing.Point(20, 16);
            this.txtGetIDphong.Name = "txtGetIDphong";
            this.txtGetIDphong.Size = new System.Drawing.Size(51, 27);
            this.txtGetIDphong.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbTTP);
            this.groupBox1.Controls.Add(this.btnTTP_Save);
            this.groupBox1.Controls.Add(this.btnPhong_Update);
            this.groupBox1.Location = new System.Drawing.Point(709, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 171);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tình trạng phòng";
            // 
            // cbTTP
            // 
            this.cbTTP.Enabled = false;
            this.cbTTP.FormattingEnabled = true;
            this.cbTTP.Items.AddRange(new object[] {
            "Trống",
            "Thuê"});
            this.cbTTP.Location = new System.Drawing.Point(28, 36);
            this.cbTTP.Name = "cbTTP";
            this.cbTTP.Size = new System.Drawing.Size(176, 28);
            this.cbTTP.TabIndex = 0;
            this.cbTTP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTTP_KeyPress);
            // 
            // btnTTP_Save
            // 
            this.btnTTP_Save.Location = new System.Drawing.Point(120, 92);
            this.btnTTP_Save.Name = "btnTTP_Save";
            this.btnTTP_Save.Size = new System.Drawing.Size(102, 53);
            this.btnTTP_Save.TabIndex = 5;
            this.btnTTP_Save.Text = "Lưu";
            this.btnTTP_Save.UseVisualStyleBackColor = true;
            this.btnTTP_Save.Visible = false;
            this.btnTTP_Save.Click += new System.EventHandler(this.btnTTP_Save_Click);
            // 
            // btnPhong_Update
            // 
            this.btnPhong_Update.Location = new System.Drawing.Point(10, 92);
            this.btnPhong_Update.Name = "btnPhong_Update";
            this.btnPhong_Update.Size = new System.Drawing.Size(102, 53);
            this.btnPhong_Update.TabIndex = 5;
            this.btnPhong_Update.Text = "Cập nhật";
            this.btnPhong_Update.UseVisualStyleBackColor = true;
            this.btnPhong_Update.Click += new System.EventHandler(this.btnPhong_Update_Click);
            // 
            // btn_VTP
            // 
            this.btn_VTP.AccessibleDescription = "";
            this.btn_VTP.Location = new System.Drawing.Point(709, 257);
            this.btn_VTP.Name = "btn_VTP";
            this.btn_VTP.Size = new System.Drawing.Size(232, 62);
            this.btn_VTP.TabIndex = 5;
            this.btn_VTP.Tag = "";
            this.btn_VTP.Text = "Xem vật tư trong phòng";
            this.btn_VTP.UseVisualStyleBackColor = true;
            this.btn_VTP.Click += new System.EventHandler(this.btn_VTP_Click);
            // 
            // tabKHvaTP
            // 
            this.tabKHvaTP.Controls.Add(this.dgv_KhachHang);
            this.tabKHvaTP.Controls.Add(this.panelTP);
            this.tabKHvaTP.Controls.Add(this.btnTP_TurnBack);
            this.tabKHvaTP.Controls.Add(this.btnTTKH_Update);
            this.tabKHvaTP.Controls.Add(this.btnTP);
            this.tabKHvaTP.Controls.Add(this.btnKH_insert);
            this.tabKHvaTP.Controls.Add(this.panel1);
            this.tabKHvaTP.Location = new System.Drawing.Point(4, 29);
            this.tabKHvaTP.Name = "tabKHvaTP";
            this.tabKHvaTP.Padding = new System.Windows.Forms.Padding(3);
            this.tabKHvaTP.Size = new System.Drawing.Size(1080, 550);
            this.tabKHvaTP.TabIndex = 1;
            this.tabKHvaTP.Text = "Khách hàng";
            this.tabKHvaTP.UseVisualStyleBackColor = true;
            // 
            // dgv_KhachHang
            // 
            this.dgv_KhachHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_KhachHang.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgv_KhachHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_KhachHang.Location = new System.Drawing.Point(39, 39);
            this.dgv_KhachHang.Name = "dgv_KhachHang";
            this.dgv_KhachHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_KhachHang.Size = new System.Drawing.Size(641, 376);
            this.dgv_KhachHang.TabIndex = 0;
            // 
            // panelTP
            // 
            this.panelTP.Controls.Add(this.groupBox4);
            this.panelTP.Controls.Add(this.groupBox3);
            this.panelTP.Enabled = false;
            this.panelTP.Location = new System.Drawing.Point(686, 36);
            this.panelTP.Name = "panelTP";
            this.panelTP.Size = new System.Drawing.Size(357, 449);
            this.panelTP.TabIndex = 5;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnNT_update);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.btnNT_Save);
            this.groupBox4.Controls.Add(this.dtpTP_NgayTra);
            this.groupBox4.Location = new System.Drawing.Point(7, 298);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(347, 142);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Trả phòng";
            // 
            // btnNT_update
            // 
            this.btnNT_update.Location = new System.Drawing.Point(53, 83);
            this.btnNT_update.Name = "btnNT_update";
            this.btnNT_update.Size = new System.Drawing.Size(101, 39);
            this.btnNT_update.TabIndex = 3;
            this.btnNT_update.Text = "Cập nhật";
            this.btnNT_update.UseVisualStyleBackColor = true;
            this.btnNT_update.Click += new System.EventHandler(this.btnNT_update_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ngày trả";
            // 
            // btnNT_Save
            // 
            this.btnNT_Save.Enabled = false;
            this.btnNT_Save.Location = new System.Drawing.Point(186, 83);
            this.btnNT_Save.Name = "btnNT_Save";
            this.btnNT_Save.Size = new System.Drawing.Size(101, 39);
            this.btnNT_Save.TabIndex = 3;
            this.btnNT_Save.Text = "Lưu";
            this.btnNT_Save.UseVisualStyleBackColor = true;
            this.btnNT_Save.Click += new System.EventHandler(this.btnNT_Save_Click);
            // 
            // dtpTP_NgayTra
            // 
            this.dtpTP_NgayTra.CustomFormat = "dd-MM-yyyy";
            this.dtpTP_NgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTP_NgayTra.Location = new System.Drawing.Point(165, 37);
            this.dtpTP_NgayTra.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtpTP_NgayTra.Name = "dtpTP_NgayTra";
            this.dtpTP_NgayTra.Size = new System.Drawing.Size(136, 27);
            this.dtpTP_NgayTra.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbTP_SoPH);
            this.groupBox3.Controls.Add(this.btnTP_Insert);
            this.groupBox3.Controls.Add(this.btnTP_Save);
            this.groupBox3.Controls.Add(this.btnTP_update);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.dtpTP_NgayDuKien);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.dtpTP_NgayThue);
            this.groupBox3.Location = new System.Drawing.Point(7, 8);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(347, 267);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thuê phòng";
            // 
            // cbTP_SoPH
            // 
            this.cbTP_SoPH.Enabled = false;
            this.cbTP_SoPH.FormattingEnabled = true;
            this.cbTP_SoPH.Location = new System.Drawing.Point(165, 38);
            this.cbTP_SoPH.Name = "cbTP_SoPH";
            this.cbTP_SoPH.Size = new System.Drawing.Size(136, 28);
            this.cbTP_SoPH.TabIndex = 4;
            this.cbTP_SoPH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTTP_KeyPress);
            // 
            // btnTP_Insert
            // 
            this.btnTP_Insert.Location = new System.Drawing.Point(10, 196);
            this.btnTP_Insert.Name = "btnTP_Insert";
            this.btnTP_Insert.Size = new System.Drawing.Size(101, 39);
            this.btnTP_Insert.TabIndex = 3;
            this.btnTP_Insert.Text = "Thêm";
            this.btnTP_Insert.UseVisualStyleBackColor = true;
            this.btnTP_Insert.Click += new System.EventHandler(this.btnTP_Insert_Click);
            // 
            // btnTP_Save
            // 
            this.btnTP_Save.Enabled = false;
            this.btnTP_Save.Location = new System.Drawing.Point(228, 196);
            this.btnTP_Save.Name = "btnTP_Save";
            this.btnTP_Save.Size = new System.Drawing.Size(101, 39);
            this.btnTP_Save.TabIndex = 3;
            this.btnTP_Save.Text = "Lưu";
            this.btnTP_Save.UseVisualStyleBackColor = true;
            this.btnTP_Save.Click += new System.EventHandler(this.btnTP_Save_Click);
            // 
            // btnTP_update
            // 
            this.btnTP_update.Location = new System.Drawing.Point(121, 196);
            this.btnTP_update.Name = "btnTP_update";
            this.btnTP_update.Size = new System.Drawing.Size(101, 39);
            this.btnTP_update.TabIndex = 3;
            this.btnTP_update.Text = "Cập nhật";
            this.btnTP_update.UseVisualStyleBackColor = true;
            this.btnTP_update.Click += new System.EventHandler(this.btnTP_update_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ngày dự kiến trả";
            // 
            // dtpTP_NgayDuKien
            // 
            this.dtpTP_NgayDuKien.CustomFormat = "dd-MM-yyyy";
            this.dtpTP_NgayDuKien.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTP_NgayDuKien.Location = new System.Drawing.Point(165, 138);
            this.dtpTP_NgayDuKien.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtpTP_NgayDuKien.Name = "dtpTP_NgayDuKien";
            this.dtpTP_NgayDuKien.Size = new System.Drawing.Size(136, 27);
            this.dtpTP_NgayDuKien.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Số phòng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ngày thuê";
            // 
            // dtpTP_NgayThue
            // 
            this.dtpTP_NgayThue.CustomFormat = "dd-MM-yyyy";
            this.dtpTP_NgayThue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTP_NgayThue.Location = new System.Drawing.Point(165, 90);
            this.dtpTP_NgayThue.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtpTP_NgayThue.Name = "dtpTP_NgayThue";
            this.dtpTP_NgayThue.Size = new System.Drawing.Size(136, 27);
            this.dtpTP_NgayThue.TabIndex = 1;
            // 
            // btnTP_TurnBack
            // 
            this.btnTP_TurnBack.Location = new System.Drawing.Point(524, 446);
            this.btnTP_TurnBack.Name = "btnTP_TurnBack";
            this.btnTP_TurnBack.Size = new System.Drawing.Size(129, 71);
            this.btnTP_TurnBack.TabIndex = 3;
            this.btnTP_TurnBack.Text = "Trở về";
            this.btnTP_TurnBack.UseVisualStyleBackColor = true;
            this.btnTP_TurnBack.Visible = false;
            this.btnTP_TurnBack.Click += new System.EventHandler(this.btnTP_TurnBack_Click);
            // 
            // btnTTKH_Update
            // 
            this.btnTTKH_Update.Location = new System.Drawing.Point(199, 446);
            this.btnTTKH_Update.Name = "btnTTKH_Update";
            this.btnTTKH_Update.Size = new System.Drawing.Size(129, 71);
            this.btnTTKH_Update.TabIndex = 3;
            this.btnTTKH_Update.Text = "Sửa thông tin\r\nkhách hàng";
            this.btnTTKH_Update.UseVisualStyleBackColor = true;
            this.btnTTKH_Update.Click += new System.EventHandler(this.btnTTKH_Update_Click);
            // 
            // btnTP
            // 
            this.btnTP.Location = new System.Drawing.Point(362, 446);
            this.btnTP.Name = "btnTP";
            this.btnTP.Size = new System.Drawing.Size(129, 71);
            this.btnTP.TabIndex = 3;
            this.btnTP.Text = "Xem chi tiết thuê phòng";
            this.btnTP.UseVisualStyleBackColor = true;
            this.btnTP.Click += new System.EventHandler(this.btnTP_Click);
            // 
            // btnKH_insert
            // 
            this.btnKH_insert.Location = new System.Drawing.Point(39, 446);
            this.btnKH_insert.Name = "btnKH_insert";
            this.btnKH_insert.Size = new System.Drawing.Size(129, 71);
            this.btnKH_insert.TabIndex = 3;
            this.btnKH_insert.Text = "Thêm thông tin\r\nkhách hàng";
            this.btnKH_insert.UseVisualStyleBackColor = true;
            this.btnKH_insert.Click += new System.EventHandler(this.btnKH_insert_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtGetIDPH);
            this.panel1.Controls.Add(this.txtGetIDMaTP);
            this.panel1.Controls.Add(this.txtGetIDKH);
            this.panel1.Location = new System.Drawing.Point(71, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(354, 57);
            this.panel1.TabIndex = 7;
            // 
            // txtGetIDPH
            // 
            this.txtGetIDPH.Location = new System.Drawing.Point(235, 9);
            this.txtGetIDPH.Name = "txtGetIDPH";
            this.txtGetIDPH.Size = new System.Drawing.Size(100, 27);
            this.txtGetIDPH.TabIndex = 6;
            // 
            // txtGetIDMaTP
            // 
            this.txtGetIDMaTP.Location = new System.Drawing.Point(23, 9);
            this.txtGetIDMaTP.Name = "txtGetIDMaTP";
            this.txtGetIDMaTP.Size = new System.Drawing.Size(100, 27);
            this.txtGetIDMaTP.TabIndex = 6;
            // 
            // txtGetIDKH
            // 
            this.txtGetIDKH.Location = new System.Drawing.Point(129, 9);
            this.txtGetIDKH.Name = "txtGetIDKH";
            this.txtGetIDKH.Size = new System.Drawing.Size(100, 27);
            this.txtGetIDKH.TabIndex = 6;
            // 
            // tabDV
            // 
            this.tabDV.Controls.Add(this.dgv_DV);
            this.tabDV.Controls.Add(this.panel3);
            this.tabDV.Controls.Add(this.btnDV_Update);
            this.tabDV.Controls.Add(this.btnDV_Save);
            this.tabDV.Controls.Add(this.btnDV_Del);
            this.tabDV.Controls.Add(this.btnDV_Insert);
            this.tabDV.Controls.Add(this.txtDV_SoLuong);
            this.tabDV.Controls.Add(this.cbDV_TenDV);
            this.tabDV.Controls.Add(this.cbDV_CMND);
            this.tabDV.Controls.Add(this.label8);
            this.tabDV.Controls.Add(this.label7);
            this.tabDV.Controls.Add(this.label6);
            this.tabDV.Location = new System.Drawing.Point(4, 29);
            this.tabDV.Name = "tabDV";
            this.tabDV.Size = new System.Drawing.Size(1080, 550);
            this.tabDV.TabIndex = 3;
            this.tabDV.Text = "Dịch vụ";
            this.tabDV.UseVisualStyleBackColor = true;
            // 
            // dgv_DV
            // 
            this.dgv_DV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgv_DV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgv_DV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_DV.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_DV.Location = new System.Drawing.Point(39, 39);
            this.dgv_DV.Name = "dgv_DV";
            this.dgv_DV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_DV.Size = new System.Drawing.Size(641, 476);
            this.dgv_DV.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txtGetIDDV);
            this.panel3.Controls.Add(this.txtGetIDPDV);
            this.panel3.Controls.Add(this.txtGetIDKH_DV);
            this.panel3.Location = new System.Drawing.Point(63, 68);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(242, 43);
            this.panel3.TabIndex = 6;
            // 
            // txtGetIDDV
            // 
            this.txtGetIDDV.Location = new System.Drawing.Point(82, 6);
            this.txtGetIDDV.Name = "txtGetIDDV";
            this.txtGetIDDV.Size = new System.Drawing.Size(70, 27);
            this.txtGetIDDV.TabIndex = 5;
            // 
            // txtGetIDPDV
            // 
            this.txtGetIDPDV.Location = new System.Drawing.Point(6, 6);
            this.txtGetIDPDV.Name = "txtGetIDPDV";
            this.txtGetIDPDV.Size = new System.Drawing.Size(70, 27);
            this.txtGetIDPDV.TabIndex = 5;
            // 
            // txtGetIDKH_DV
            // 
            this.txtGetIDKH_DV.Location = new System.Drawing.Point(158, 6);
            this.txtGetIDKH_DV.Name = "txtGetIDKH_DV";
            this.txtGetIDKH_DV.Size = new System.Drawing.Size(70, 27);
            this.txtGetIDKH_DV.TabIndex = 5;
            // 
            // btnDV_Update
            // 
            this.btnDV_Update.Location = new System.Drawing.Point(879, 244);
            this.btnDV_Update.Name = "btnDV_Update";
            this.btnDV_Update.Size = new System.Drawing.Size(116, 68);
            this.btnDV_Update.TabIndex = 4;
            this.btnDV_Update.Text = "Cập nhật phiếu dịch vụ";
            this.btnDV_Update.UseVisualStyleBackColor = true;
            this.btnDV_Update.Click += new System.EventHandler(this.btnDV_Update_Click);
            // 
            // btnDV_Save
            // 
            this.btnDV_Save.Enabled = false;
            this.btnDV_Save.Location = new System.Drawing.Point(879, 335);
            this.btnDV_Save.Name = "btnDV_Save";
            this.btnDV_Save.Size = new System.Drawing.Size(117, 68);
            this.btnDV_Save.TabIndex = 4;
            this.btnDV_Save.Text = "Lưu";
            this.btnDV_Save.UseVisualStyleBackColor = true;
            this.btnDV_Save.Click += new System.EventHandler(this.btnDV_Save_Click);
            // 
            // btnDV_Del
            // 
            this.btnDV_Del.Location = new System.Drawing.Point(739, 335);
            this.btnDV_Del.Name = "btnDV_Del";
            this.btnDV_Del.Size = new System.Drawing.Size(117, 68);
            this.btnDV_Del.TabIndex = 4;
            this.btnDV_Del.Text = "Xóa phiếu \r\ndịch vụ";
            this.btnDV_Del.UseVisualStyleBackColor = true;
            this.btnDV_Del.Click += new System.EventHandler(this.btnDV_Del_Click);
            // 
            // btnDV_Insert
            // 
            this.btnDV_Insert.Location = new System.Drawing.Point(739, 244);
            this.btnDV_Insert.Name = "btnDV_Insert";
            this.btnDV_Insert.Size = new System.Drawing.Size(117, 68);
            this.btnDV_Insert.TabIndex = 4;
            this.btnDV_Insert.Text = "Thêm phiếu \r\ndịch vụ";
            this.btnDV_Insert.UseVisualStyleBackColor = true;
            this.btnDV_Insert.Click += new System.EventHandler(this.btnDV_Insert_Click);
            // 
            // txtDV_SoLuong
            // 
            this.txtDV_SoLuong.Enabled = false;
            this.txtDV_SoLuong.Location = new System.Drawing.Point(853, 179);
            this.txtDV_SoLuong.Name = "txtDV_SoLuong";
            this.txtDV_SoLuong.Size = new System.Drawing.Size(100, 27);
            this.txtDV_SoLuong.TabIndex = 3;
            this.txtDV_SoLuong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDV_SoLuong_KeyPress);
            // 
            // cbDV_TenDV
            // 
            this.cbDV_TenDV.Enabled = false;
            this.cbDV_TenDV.Location = new System.Drawing.Point(853, 122);
            this.cbDV_TenDV.Name = "cbDV_TenDV";
            this.cbDV_TenDV.Size = new System.Drawing.Size(176, 28);
            this.cbDV_TenDV.TabIndex = 2;
            this.cbDV_TenDV.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbDV_TenDV_KeyPress);
            // 
            // cbDV_CMND
            // 
            this.cbDV_CMND.Enabled = false;
            this.cbDV_CMND.FormattingEnabled = true;
            this.cbDV_CMND.Location = new System.Drawing.Point(853, 68);
            this.cbDV_CMND.Name = "cbDV_CMND";
            this.cbDV_CMND.Size = new System.Drawing.Size(176, 28);
            this.cbDV_CMND.TabIndex = 2;
            this.cbDV_CMND.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbDV_CMND_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(697, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Số lượng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(697, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Dịch vụ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(697, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "CMND khách hàng";
            // 
            // Main_QLKS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 583);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Main_QLKS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý khách sạn";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_QLKS_FormClosed);
            this.Load += new System.EventHandler(this.Main_QLKS_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPhong.ResumeLayout(false);
            this.panelVTP.ResumeLayout(false);
            this.panelVTP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabKHvaTP.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_KhachHang)).EndInit();
            this.panelTP.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabDV.ResumeLayout(false);
            this.tabDV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DV)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPhong;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.TabPage tabKHvaTP;
        private System.Windows.Forms.DataGridView dgv_KhachHang;
        private System.Windows.Forms.DateTimePicker dtpTP_NgayThue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpTP_NgayDuKien;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpTP_NgayTra;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnNT_update;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnTP_update;
        private System.Windows.Forms.Button btnKH_insert;
        private System.Windows.Forms.Button btnPhong_Update;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnTTKH_Update;
        private System.Windows.Forms.TabPage tabDV;
        private System.Windows.Forms.TextBox txtVTP_SoLuong;
        private System.Windows.Forms.Button btnVTP_Del;
        private System.Windows.Forms.Button btnVTP_Insert;
        private System.Windows.Forms.Button btnVTP_Update;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv_DV;
        private System.Windows.Forms.Button btnDV_Update;
        private System.Windows.Forms.Button btnDV_Del;
        private System.Windows.Forms.Button btnDV_Insert;
        private System.Windows.Forms.TextBox txtDV_SoLuong;
        private System.Windows.Forms.ComboBox cbDV_TenDV;
        private System.Windows.Forms.ComboBox cbDV_CMND;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbTP_SoPH;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbTTP;
        private System.Windows.Forms.Button btnTTP_Save;
        private System.Windows.Forms.TextBox txtGetIDphong;
        private System.Windows.Forms.Button btn_VTP;
        private System.Windows.Forms.Panel panelVTP;
        private System.Windows.Forms.Button btnVTP_TurnBack;
        private System.Windows.Forms.ComboBox cbVTP_TenVT;
        private System.Windows.Forms.Button btnVTP_Save;
        private System.Windows.Forms.TextBox txtGetIDVT;
        private System.Windows.Forms.Button btnTP_TurnBack;
        private System.Windows.Forms.Button btnTP;
        private System.Windows.Forms.Panel panelTP;
        private System.Windows.Forms.TextBox txtGetIDKH;
        private System.Windows.Forms.TextBox txtGetIDPH;
        private System.Windows.Forms.Button btnNT_Save;
        private System.Windows.Forms.Button btnTP_Insert;
        private System.Windows.Forms.Button btnTP_Save;
        private System.Windows.Forms.TextBox txtGetIDMaTP;
        private System.Windows.Forms.Button btnDV_Save;
        private System.Windows.Forms.TextBox txtGetIDPDV;
        private System.Windows.Forms.TextBox txtGetIDDV;
        private System.Windows.Forms.TextBox txtGetIDKH_DV;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
    }
}

