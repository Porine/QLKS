﻿
namespace QLKS.Views
{
    partial class frm_ThongTinKH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTTKH_Hoten = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTTKH_CMND = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTTKH_SDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTTKH_DC = new System.Windows.Forms.TextBox();
            this.btnTTKH_Save = new System.Windows.Forms.Button();
            this.dgvTTKH = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTTKH)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ tên";
            // 
            // txtTTKH_Hoten
            // 
            this.txtTTKH_Hoten.Location = new System.Drawing.Point(106, 35);
            this.txtTTKH_Hoten.Name = "txtTTKH_Hoten";
            this.txtTTKH_Hoten.Size = new System.Drawing.Size(337, 27);
            this.txtTTKH_Hoten.TabIndex = 0;
            this.txtTTKH_Hoten.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTTKH_Hoten_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(490, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "CMND";
            // 
            // txtTTKH_CMND
            // 
            this.txtTTKH_CMND.Location = new System.Drawing.Point(604, 94);
            this.txtTTKH_CMND.Name = "txtTTKH_CMND";
            this.txtTTKH_CMND.Size = new System.Drawing.Size(192, 27);
            this.txtTTKH_CMND.TabIndex = 3;
            this.txtTTKH_CMND.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTTKH_CMND_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(490, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Số điện thoại";
            // 
            // txtTTKH_SDT
            // 
            this.txtTTKH_SDT.Location = new System.Drawing.Point(604, 35);
            this.txtTTKH_SDT.Name = "txtTTKH_SDT";
            this.txtTTKH_SDT.Size = new System.Drawing.Size(192, 27);
            this.txtTTKH_SDT.TabIndex = 1;
            this.txtTTKH_SDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTTKH_SDT_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Địa chỉ";
            // 
            // txtTTKH_DC
            // 
            this.txtTTKH_DC.Location = new System.Drawing.Point(106, 94);
            this.txtTTKH_DC.Name = "txtTTKH_DC";
            this.txtTTKH_DC.Size = new System.Drawing.Size(337, 27);
            this.txtTTKH_DC.TabIndex = 2;
            this.txtTTKH_DC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTTKH_DC_KeyPress);
            // 
            // btnTTKH_Save
            // 
            this.btnTTKH_Save.Location = new System.Drawing.Point(335, 170);
            this.btnTTKH_Save.Name = "btnTTKH_Save";
            this.btnTTKH_Save.Size = new System.Drawing.Size(129, 47);
            this.btnTTKH_Save.TabIndex = 4;
            this.btnTTKH_Save.Text = "Lưu";
            this.btnTTKH_Save.UseVisualStyleBackColor = true;
            this.btnTTKH_Save.Click += new System.EventHandler(this.btnTTKH_Save_Click);
            // 
            // dgvTTKH
            // 
            this.dgvTTKH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTTKH.Location = new System.Drawing.Point(610, 222);
            this.dgvTTKH.Name = "dgvTTKH";
            this.dgvTTKH.Size = new System.Drawing.Size(213, 23);
            this.dgvTTKH.TabIndex = 10;
            this.dgvTTKH.Visible = false;
            // 
            // frm_ThongTinKH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 257);
            this.Controls.Add(this.dgvTTKH);
            this.Controls.Add(this.btnTTKH_Save);
            this.Controls.Add(this.txtTTKH_SDT);
            this.Controls.Add(this.txtTTKH_CMND);
            this.Controls.Add(this.txtTTKH_DC);
            this.Controls.Add(this.txtTTKH_Hoten);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frm_ThongTinKH";
            this.Load += new System.EventHandler(this.frm_ThongTinKH_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTTKH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTTKH_Hoten;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTTKH_CMND;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTTKH_SDT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTTKH_DC;
        private System.Windows.Forms.Button btnTTKH_Save;
        private System.Windows.Forms.DataGridView dgvTTKH;
    }
}