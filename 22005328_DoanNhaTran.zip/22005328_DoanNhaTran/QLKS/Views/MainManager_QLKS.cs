﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLKS.Controller;

namespace QLKS.Views
{
    public partial class MainManager_QLKS : Form
    {
        public MainManager_QLKS()
        {
            InitializeComponent();
        }

        private void MainManager_QLKS_Load(object sender, EventArgs e)
        {
            LoadDGV_NV();
            loadDGV_TK();
            LoadDGV_QLDV();
            LoadDGV_PH();
        }

        #region KeyHandle
        
        private void txtNV_HoTen_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsPunctuation(e.KeyChar)) e.Handled = true;
        }

        private void cbNV_ChucVu_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtNV_DC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsSymbol(e.KeyChar)) e.Handled = true;
        }

        private void txtNV_CMND_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)) e.Handled = true;
        }

        private void txtTK_TenDN_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsWhiteSpace(e.KeyChar)  || char.IsSymbol(e.KeyChar) || char.IsPunctuation(e.KeyChar)) e.Handled = true;
        }
        
        private void txtDV_GiaDV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)) e.Handled = true;
        }
        #endregion

        #region NhanVien
        bool InsertNV = false, UpdateNV = false;
        clsNV nv = new clsNV();

        void BindingDataNV()
        {
            txtGetIDNV.DataBindings.Clear();
            txtNV_CMND.DataBindings.Clear();
            txtNV_DC.DataBindings.Clear();
            txtNV_HoTen.DataBindings.Clear();
            cbNV_ChucVu.DataBindings.Clear();
            dtpNV_NVL.DataBindings.Clear();

            txtGetIDNV.DataBindings.Add("Text", dgv_QLNV.DataSource, "MaNV");
            txtNV_CMND.DataBindings.Add("Text", dgv_QLNV.DataSource, "CMND");
            txtNV_DC.DataBindings.Add("Text", dgv_QLNV.DataSource, "DiaChi");
            txtNV_HoTen.DataBindings.Add("Text", dgv_QLNV.DataSource, "HoTen");
            cbNV_ChucVu.DataBindings.Add("Text", dgv_QLNV.DataSource, "ChucVu");
            dtpNV_NVL.DataBindings.Add("Text", dgv_QLNV.DataSource, "NgayVaoLam", true);
        }

        void LoadDGV_NV()
        {
            dgv_QLNV.DataSource = nv.Display_NhanVien();

            dgv_QLNV.Columns["MaNV"].HeaderText = "Mã nhân viên";
            dgv_QLNV.Columns["HoTen"].HeaderText = "Họ tên";
            dgv_QLNV.Columns["DiaChi"].HeaderText = "Địa chỉ";
            dgv_QLNV.Columns["NgayVaoLam"].HeaderText = "Ngày vào làm";
            dgv_QLNV.Columns["NgayVaoLam"].DefaultCellStyle.Format = "dd-MM-yyyy";
            dgv_QLNV.Columns["ChucVu"].HeaderText = "Chức vụ";

            BindingDataNV();
        }

        private void btnNV_Insert_Click(object sender, EventArgs e)
        {
            btnNV_Del.Enabled = false;
            btnNV_Update.Enabled = false;
            btnNV_Save.Enabled = true;

            dgv_QLNV.Enabled = false;

            txtNV_CMND.Enabled = true;
            txtNV_DC.Enabled = true;
            txtNV_HoTen.Enabled = true;
            cbNV_ChucVu.Enabled = true;
            dtpNV_NVL.Enabled = true;

            txtNV_CMND.Clear();
            txtNV_DC.Clear();
            txtNV_HoTen.Clear();
            dtpNV_NVL.Value = DateTime.Now;

            InsertNV = true;
        }

        private void btnNV_Save_Click(object sender, EventArgs e)
        {
            int rec, matk = cbNV_ChucVu.SelectedIndex + 1;

            if(txtNV_HoTen.TextLength == 0)
            {
                MessageBox.Show("Họ tên không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtNV_HoTen.Focus();
            }
            else if (txtNV_HoTen.TextLength > 100)
            {
                MessageBox.Show("Họ tên không được quá 100 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                txtNV_HoTen.Focus();
            }
            else if(txtNV_DC.TextLength == 0)
            {
                MessageBox.Show("Địa chỉ không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtNV_DC.Focus();
            }
            else if(txtNV_DC.TextLength > 150)
            {
                MessageBox.Show("Địa chỉ không được quá 150 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                txtNV_DC.Focus();
            }
            else if(txtNV_CMND.TextLength < 11 || txtNV_CMND.TextLength > 12 )
            {
                MessageBox.Show("CMND phải đủ 12 số!", "Thông báo!", MessageBoxButtons.OK);
                txtNV_CMND.Focus();
            }
            else
            {
                if(InsertNV == true)
                {
                    rec = nv.Insert_NhanVien(matk, txtNV_HoTen.Text, txtNV_CMND.Text, txtNV_DC.Text, dtpNV_NVL.Value.ToString("dd-MM-yyyy"));
                    if(rec > 0)
                    {
                        MessageBox.Show("Thêm thành công!", "Thông báo!", MessageBoxButtons.OK);

                        btnNV_Del.Enabled = true;
                        btnNV_Update.Enabled = true;
                        btnNV_Save.Enabled = false;

                        dgv_QLNV.Enabled = true;

                        txtNV_CMND.Enabled = false;
                        txtNV_DC.Enabled = false;
                        txtNV_HoTen.Enabled = false;
                        cbNV_ChucVu.Enabled = false;
                        dtpNV_NVL.Enabled = false;

                        InsertNV = false;

                        LoadDGV_NV();
                    }
                    else MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
                }
                else if (UpdateNV == true)
                {
                    rec = nv.Update_NhanVien(int.Parse(txtGetIDNV.Text), matk, txtNV_HoTen.Text, txtNV_CMND.Text, txtNV_DC.Text, dtpNV_NVL.Value.ToString("dd-MM-yyyy"));
                    if (rec > 0)
                    {
                        MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);

                        btnNV_Del.Enabled = true;
                        btnNV_Insert.Enabled = true;
                        btnNV_Save.Enabled = false;

                        dgv_QLNV.Enabled = true;

                        txtNV_CMND.Enabled = false;
                        txtNV_DC.Enabled = false;
                        txtNV_HoTen.Enabled = false;
                        cbNV_ChucVu.Enabled = false;
                        dtpNV_NVL.Enabled = false;

                        UpdateNV = false;

                        LoadDGV_NV();
                    }
                    else MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
                }
            }
        }

        private void btnNV_Del_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Xóa nhân viên này?", "Thông báo!", MessageBoxButtons.YesNo);
            if (tb == DialogResult.Yes)
            {
                int rec = nv.Del_NhanVien(int.Parse(txtGetIDNV.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Xóa thành công!", "Thông báo!", MessageBoxButtons.OK);
                    LoadDGV_NV();
                }
                else MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
            
        }

        private void btnNV_Update_Click(object sender, EventArgs e)
        {
            btnNV_Del.Enabled = false;
            btnNV_Insert.Enabled = false;
            btnNV_Save.Enabled = true;

            dgv_QLNV.Enabled = false;

            txtNV_CMND.Enabled = true;
            txtNV_DC.Enabled = true;
            txtNV_HoTen.Enabled = true;
            cbNV_ChucVu.Enabled = true;
            dtpNV_NVL.Enabled = true;

            UpdateNV = true;
        }

        #endregion

        #region TaiKhoan
        clsTK tk = new clsTK();

        void BindingDataTK()
        {
            txtGetIDTK.DataBindings.Clear();
            txtTK_MK.DataBindings.Clear();
            txtTK_TenDN.DataBindings.Clear();

            txtGetIDTK.DataBindings.Add("Text", dgvTK.DataSource, "MaTK");
            txtTK_MK.DataBindings.Add("Text", dgvTK.DataSource, "MatKhau");
            txtTK_TenDN.DataBindings.Add("Text", dgvTK.DataSource, "TenDN");
        }

        private void btnTK_Save_Click(object sender, EventArgs e)
        {
            if (txtTK_TenDN.TextLength == 0)
            {
                MessageBox.Show("Tên đăng nhập không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtTK_TenDN.Focus();
            }
            else if (txtTK_TenDN.TextLength > 20)
            {
                MessageBox.Show("Tên đăng nhập không được quá 20 số!", "Thông báo!", MessageBoxButtons.OK);
                txtTK_TenDN.Focus();
            }
            else if (txtTK_MK.TextLength == 0)
            {
                MessageBox.Show("Mật khẩu không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtTK_MK.Focus();
            }
            else if (txtTK_MK.TextLength > 20)
            {
                MessageBox.Show("Mật khẩu không được quá 20 số!", "Thông báo!", MessageBoxButtons.OK);
                txtTK_MK.Focus();
            }
            else
            {
                int rec = tk.Update_TaiKhoan(int.Parse(txtGetIDTK.Text), txtTK_TenDN.Text, txtTK_MK.Text);
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);

                    txtTK_TenDN.Enabled = false;
                    txtTK_MK.Enabled = false;

                    btnTK_Save.Enabled = false;

                    dgvTK.Enabled = true;

                    loadDGV_TK();
                }
                else if (rec == -2)
                {
                    MessageBox.Show("Tên đăng nhập không được trùng nhau!", "Thông báo!", MessageBoxButtons.OK);
                    txtTK_TenDN.Focus();
                }
                else MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnTK_Update_Click(object sender, EventArgs e)
        {
            txtTK_TenDN.Enabled = true;
            txtTK_MK.Enabled = true;

            btnTK_Save.Enabled = true;

            dgvTK.Enabled = false;
        }

        void loadDGV_TK()
        {
            dgvTK.DataSource = tk.Display_TaiKhoan();

            dgvTK.Columns["MaTK"].HeaderText = "Mã tài khoản";
            dgvTK.Columns["TenDN"].HeaderText = "Tên đăng nhập";
            dgvTK.Columns["MatKhau"].HeaderText = "Mật khẩu";
            dgvTK.Columns["ChucVu"].HeaderText = "Chức vụ";

            BindingDataTK();
        }

        #endregion

        #region DichVu
        bool InsertDV = false, UpdateDV = false;
        clsQLDV dv = new clsQLDV();

        void BindingDataQLDV()
        {
            txtDV_GiaDV.DataBindings.Clear();
            txtDV_TenDV.DataBindings.Clear();
            txtGetIDDV_QL.DataBindings.Clear();

            txtDV_GiaDV.DataBindings.Add("Text", dgvQLDV.DataSource, "GiaDV");
            txtDV_TenDV.DataBindings.Add("Text", dgvQLDV.DataSource, "TenDV");
            txtGetIDDV_QL.DataBindings.Add("Text", dgvQLDV.DataSource, "MaDV");
        }

        void LoadDGV_QLDV()
        {
            dgvQLDV.DataSource = dv.Display_DichVu();

            dgvQLDV.Columns["MaDV"].HeaderText = "Mã dịch vụ";
            dgvQLDV.Columns["TenDV"].HeaderText = "Tên dịch vụ";
            dgvQLDV.Columns["GiaDV"].HeaderText = "Giá dịch vụ";

            BindingDataQLDV();
        }

        private void btnDV_Update_Click(object sender, EventArgs e)
        {
            txtDV_TenDV.Enabled = true;
            txtDV_GiaDV.Enabled = true;

            dgvQLDV.Enabled = false;

            btnDV_Del.Enabled = false;
            btnDV_Insert.Enabled = false;
            btnDV_Save.Enabled = true;

            UpdateDV = true;
        }

        private void btnDV_Del_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Xóa dịch vụ này?\nĐồng thời cũng sẽ xóa TẤT CẢ những phiếu dịch vụ có mã dịch vụ này!", "Thông báo!", MessageBoxButtons.YesNo);
            if(tb == DialogResult.Yes)
            {
                int rec, madv = int.Parse(txtGetIDDV_QL.Text);
                rec = dv.Del_DichVu(madv);
                if (rec > 0)
                {
                    MessageBox.Show("Xóa thành công!", "thông báo!", MessageBoxButtons.OK);
                    LoadDGV_QLDV();
                }
                else MessageBox.Show("Lỗi kết nối database!", "thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnDV_Insert_Click(object sender, EventArgs e)
        {
            txtDV_GiaDV.Clear();
            txtDV_TenDV.Clear();

            txtDV_TenDV.Enabled = true;
            txtDV_GiaDV.Enabled = true;

            dgvQLDV.Enabled = false;

            btnDV_Del.Enabled = false;
            btnDV_Update.Enabled = false;
            btnDV_Save.Enabled = true;

            InsertDV = true;
        }

        private void btnDV_Save_Click(object sender, EventArgs e)
        {
            if (txtDV_TenDV.TextLength == 0)
            {
                MessageBox.Show("Tên dịch vụ không được để trống!", "Thông báo!", MessageBoxButtons.OK);
                txtDV_TenDV.Focus();
            }
            else if (txtDV_TenDV.TextLength > 60)
            {
                MessageBox.Show("Tên dịch vụ không được quá 60 ký tự!", "Thông báo!", MessageBoxButtons.OK);
                txtDV_TenDV.Focus();
            }
            else
            {
                int rec, madv = int.Parse(txtGetIDDV_QL.Text);
                if(txtDV_GiaDV.Text.Trim().Length == 0) txtDV_GiaDV.Text = "0";
                if (InsertDV == true)
                {
                    rec = dv.Insert_DichVu(txtDV_TenDV.Text, float.Parse(txtDV_GiaDV.Text));
                    if (rec > 0)
                    {
                        MessageBox.Show("Thêm thành công!", "thông báo!", MessageBoxButtons.OK);

                        txtDV_TenDV.Enabled = false;
                        txtDV_GiaDV.Enabled = false;

                        dgvQLDV.Enabled = true;

                        btnDV_Del.Enabled = true;
                        btnDV_Update.Enabled = true;
                        btnDV_Save.Enabled = false;

                        InsertDV = false;

                        LoadDGV_QLDV();
                    }
                    else MessageBox.Show("Lỗi kết nối database!", "thông báo!", MessageBoxButtons.OK);
                }
                else if(UpdateDV == true)
                {
                    rec = dv.Update_DichVu(madv, txtDV_TenDV.Text, float.Parse(txtDV_GiaDV.Text));
                    if (rec > 0)
                    {
                        MessageBox.Show("Cập nhật thành công!", "thông báo!", MessageBoxButtons.OK);

                        txtDV_TenDV.Enabled = false;
                        txtDV_GiaDV.Enabled = false;

                        dgvQLDV.Enabled = true;

                        btnDV_Del.Enabled = true;
                        btnDV_Insert.Enabled = true;
                        btnDV_Save.Enabled = false;

                        UpdateDV = false;

                        LoadDGV_QLDV();
                    }
                    else MessageBox.Show("Lỗi kết nối database!", "thông báo!", MessageBoxButtons.OK);
                }
            }
        }
        #endregion

        #region Phong
        bool InsertPH = false, UpdatePH = false;
        clsQLPH ph = new clsQLPH();

        private void btnPH_Update_Click(object sender, EventArgs e)
        {
            if (grPhong.Enabled == true)
            {
                txtPH_SoPH.Enabled = true;
                cbPH_LP.Enabled = true;
                cbPH_TT.Enabled = true;

                btnPH_Del.Enabled = false;
                btnPH_Insert.Enabled = false;
                btnPH_DisplayLPH.Enabled = false;
                btnPH_Save.Enabled = true;

                dgvPH.Enabled = false;

                UpdatePH = true;
            }
            else if (grLP.Enabled == true)
            {
                txtLP_Gia.Enabled = true;
                txtLP_LoaiPH.Enabled = true;

                btnPH_Del.Enabled = false;
                btnPH_Insert.Enabled = false;
                btnPH_DisplayPH.Enabled = false;
                btnPH_Save.Enabled = true;

                dgvPH.Enabled = false;

                UpdatePH = true;
            }
        }

        private void btnPH_Save_Click(object sender, EventArgs e)
        {
            int rec;
            if(grPhong.Enabled==true && InsertPH == true)
            {
                int malp = ph.GetIDLPfromLoaiPH(cbPH_LP.Text);
                rec = ph.Insert_Phong(malp, int.Parse(txtPH_SoPH.Text), cbPH_TT.Text);
                if (rec > 0)
                {
                    MessageBox.Show("Thêm thành công!", "thông báo!", MessageBoxButtons.OK);

                    txtPH_SoPH.Enabled = false;
                    cbPH_LP.Enabled = false;
                    cbPH_TT.Enabled = false;

                    btnPH_Del.Enabled = true;
                    btnPH_Update.Enabled = true;
                    btnPH_DisplayLPH.Enabled = true;
                    btnPH_Save.Enabled = false;

                    dgvPH.Enabled = true;

                    InsertPH = false;

                    LoadDGV_PH();
                }
                else MessageBox.Show("Lỗi kết nối database!", "thông báo!", MessageBoxButtons.OK);
            }
            else if(grLP.Enabled==true&& InsertPH == true)
            {
                rec = ph.Insert_LP(txtLP_LoaiPH.Text, float.Parse(txtLP_Gia.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Thêm thành công!", "thông báo!", MessageBoxButtons.OK);

                    txtLP_Gia.Enabled = false;
                    txtLP_LoaiPH.Enabled = false;

                    btnPH_Del.Enabled = true;
                    btnPH_Insert.Enabled = true;
                    btnPH_DisplayPH.Enabled = true;
                    btnPH_Save.Enabled = true;

                    dgvPH.Enabled = true;

                    InsertPH = false;

                    LoadDGV_PH_LP();
                }
                else MessageBox.Show("Lỗi: "+rec.ToString()+"!", "thông báo!", MessageBoxButtons.OK);
            }
            else if(grPhong.Enabled == true && UpdatePH == true)
            {
                int malp = ph.GetIDLPfromLoaiPH(cbPH_LP.Text);
                rec = ph.Update_Phong(int.Parse(txtGetIDPH.Text), malp, int.Parse(txtPH_SoPH.Text), cbPH_TT.Text);
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "thông báo!", MessageBoxButtons.OK);

                    txtPH_SoPH.Enabled = false;
                    cbPH_LP.Enabled = false;
                    cbPH_TT.Enabled = false;

                    btnPH_Del.Enabled = true;
                    btnPH_Insert.Enabled = true;
                    btnPH_DisplayLPH.Enabled = true;
                    btnPH_Save.Enabled = false;

                    dgvPH.Enabled = true;

                    UpdatePH = false;

                    LoadDGV_PH();
                }
                else MessageBox.Show("Lỗi kết nối database!", "thông báo!", MessageBoxButtons.OK);
            }
            else if(grLP.Enabled ==true && UpdatePH == true)
            {
                rec = ph.Update_LP(int.Parse(txtGetIDLP.Text), txtLP_LoaiPH.Text, float.Parse(txtLP_Gia.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "thông báo!", MessageBoxButtons.OK);

                    txtLP_Gia.Enabled = false;
                    txtLP_LoaiPH.Enabled = false;

                    btnPH_Del.Enabled = true;
                    btnPH_Insert.Enabled = true;
                    btnPH_DisplayPH.Enabled = true;
                    btnPH_Save.Enabled = false;

                    dgvPH.Enabled = true;

                    UpdatePH = false;

                    LoadDGV_PH_LP();
                }
                else MessageBox.Show("Lỗi:"+rec.ToString(), "thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnPH_Del_Click(object sender, EventArgs e)
        {
            if (grPhong.Enabled == true)
            {
                DialogResult tb = MessageBox.Show("Xóa phòng này?\nĐồng thời cũng sẽ xóa TẤT CẢ thông tin thuê phòng có mã phòng này!", "Thông báo!", MessageBoxButtons.YesNo);
                if (tb == DialogResult.Yes)
                {
                    int rec = ph.Del_Phong(int.Parse(txtGetIDPH.Text));
                    if (rec > 0)
                    {
                        MessageBox.Show("Xóa thành công!", "Thông báo!", MessageBoxButtons.OK);
                        LoadDGV_PH();
                    }else MessageBox.Show("Lỗi: "+rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
                }
            }
            else if (grLP.Enabled == true)
            {
                DialogResult tb = MessageBox.Show("Xóa loại phòng này?\nĐồng thời cũng sẽ xóa TẤT CẢ phòng có mã loại phòng này!", "Thông báo!", MessageBoxButtons.YesNo);
                if (tb == DialogResult.Yes)
                {
                    int rec = ph.Del_LP(int.Parse(txtGetIDLP.Text));
                    if (rec > 0)
                    {
                        MessageBox.Show("Xóa thành công!", "Thông báo!", MessageBoxButtons.OK);
                        LoadDGV_PH_LP();
                    }
                    else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
                }
            }
        }

        private void btnPH_DisplayLPH_Click(object sender, EventArgs e)
        {
            LoadDGV_PH_LP();

            grLP.Enabled = true;
            grPhong.Enabled = false;
            btnPH_DisplayLPH.Enabled = false;
            btnPH_DisplayPH.Enabled = true;
        }

        private void btnPH_DisplayPH_Click(object sender, EventArgs e)
        {
            LoadDGV_PH();

            grLP.Enabled = false;
            grPhong.Enabled = true;
            btnPH_DisplayPH.Enabled = false;
            btnPH_DisplayLPH.Enabled = true;
        }

        private void btnPH_Insert_Click(object sender, EventArgs e)
        {
            if (grPhong.Enabled == true)
            {
                txtPH_SoPH.Clear();
                txtPH_SoPH.Enabled = true;
                cbPH_LP.Enabled = true;
                cbPH_TT.Enabled = true;

                btnPH_Del.Enabled = false;
                btnPH_Update.Enabled = false;
                btnPH_DisplayLPH.Enabled = false;
                btnPH_Save.Enabled = true;

                dgvPH.Enabled = false;

                InsertPH = true;
            } 
            else if (grLP.Enabled == true)
            {
                txtLP_Gia.Clear();
                txtLP_Gia.Enabled = true;
                txtLP_LoaiPH.Clear();
                txtLP_LoaiPH.Enabled = true;

                btnPH_Del.Enabled = false;
                btnPH_Update.Enabled = false;
                btnPH_DisplayPH.Enabled = false;
                btnPH_Save.Enabled = true;

                dgvPH.Enabled = false;

                InsertPH = true;
            }
        }

        void BindingDataPH()
        {
            txtGetIDPH.DataBindings.Clear();
            txtPH_SoPH.DataBindings.Clear();
            cbPH_LP.DataBindings.Clear();
            cbPH_TT.DataBindings.Clear();

            txtGetIDPH.DataBindings.Add("Text", dgvPH.DataSource, "MaPH");
            txtPH_SoPH.DataBindings.Add("Text", dgvPH.DataSource, "SoPH");
            cbPH_LP.DataBindings.Add("Text", dgvPH.DataSource, "LoaiPH");
            cbPH_TT.DataBindings.Add("Text", dgvPH.DataSource, "TinhTrangPH");
        }

        private void MainManager_QLKS_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        void LoadDGV_PH()
        {
            dgvPH.DataSource = ph.Display_Phong();
            cbPH_LP.Items.Clear();
            ph.DisplayPH_cbLP(cbPH_LP);

            dgvPH.Columns["MaPH"].HeaderText = "Mã phòng";
            dgvPH.Columns["SoPH"].HeaderText = "Số phòng";
            dgvPH.Columns["TinhTrangPH"].HeaderText = "Tình trạng";
            dgvPH.Columns["LoaiPH"].HeaderText = "Loại phòng";
            dgvPH.Columns["GiaPH"].HeaderText = "Giá phòng";

            BindingDataPH();
        }

        void BindingDataPH_LP()
        {
            txtGetIDLP.DataBindings.Clear();
            txtLP_Gia.DataBindings.Clear();
            txtLP_LoaiPH.DataBindings.Clear();

            txtGetIDLP.DataBindings.Add("Text", dgvPH.DataSource, "MaLPH");
            txtLP_Gia.DataBindings.Add("Text", dgvPH.DataSource, "GiaPH");
            txtLP_LoaiPH.DataBindings.Add("Text", dgvPH.DataSource, "LoaiPH");
        }

        void LoadDGV_PH_LP()
        {
            dgvPH.DataSource = ph.Display_LP();

            dgvPH.Columns["MaLPH"].HeaderText = "Mã loại phòng";
            dgvPH.Columns["LoaiPH"].HeaderText = "Loại phòng";
            dgvPH.Columns["GiaPH"].HeaderText = "Giá loại phòng";

            BindingDataPH_LP();
        }

        #endregion
    }
}
