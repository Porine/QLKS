﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLKS.Controller;
using QLKS.Views;
using System.Data.SqlClient;

namespace QLKS
{
    public partial class Main_QLKS : Form
    {
        public Main_QLKS()
        {
            InitializeComponent();
        }

        private void Main_QLKS_Load(object sender, EventArgs e)
        {
            loadDGV_Phong();
            loadDGV_KH();
            loadDGV_DV();
        }

        void DGVStyle(DataGridView dgv)
        {
            DataGridViewCellStyle cell = new DataGridViewCellStyle();
            cell.Font = new Font("Microsoft Sans Serif", 13, FontStyle.Regular);
            dgv.DefaultCellStyle = cell;
            dgv.ColumnHeadersDefaultCellStyle = cell;
        }

        #region KeyHandled
        private void cbTTP_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbVTP_TenVT_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtVTP_SoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar)) e.Handled = true;
        }

        private void cbDV_CMND_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbDV_TenDV_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtDV_SoLuong_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || char.IsPunctuation(e.KeyChar) || char.IsSymbol(e.KeyChar) || char.IsWhiteSpace(e.KeyChar)) 
                e.Handled = true;
        }

        #endregion

        #region Phong

        clsPhong phong = new clsPhong();

        public void BindingDataPhong()
        {
            cbTTP.DataBindings.Clear();
            txtGetIDphong.DataBindings.Clear();
            cbTTP.DataBindings.Add("Text", dgvPhong.DataSource, "TinhTrangPH");
            txtGetIDphong.DataBindings.Add("Text", dgvPhong.DataSource, "MaPH");
        }

        public void loadDGV_Phong()
        {
            dgvPhong.DataSource = phong.Display_Phong();

            DGVStyle(dgvPhong);

            dgvPhong.Columns["MaPH"].Visible = false;
            dgvPhong.Columns["SoPH"].HeaderText = "Số phòng";         
            dgvPhong.Columns["TinhTrangPH"].HeaderText = "Tình trạng";
            dgvPhong.Columns["LoaiPH"].HeaderText = "Loại";
            dgvPhong.Columns["GiaPH"].HeaderText = "Giá";
            
            BindingDataPhong();
        }

        private void btnPhong_Update_Click(object sender, EventArgs e)
        {
            btnTTP_Save.Visible = true;
            dgvPhong.Enabled = false;
            cbTTP.Enabled = true;
        }

        private void btnTTP_Save_Click(object sender, EventArgs e)
        {
            int rec; 
            rec = phong.Update_TTPhong(int.Parse(txtGetIDphong.Text) ,cbTTP.Text);
            if (rec > 0)
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);
                loadDGV_Phong();
                btnTTP_Save.Visible = false;
                dgvPhong.Enabled = true;
                cbTTP.Enabled = false;
            }
            else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
        }

        #endregion

        #region VTPhong
        bool InsertVTP = false, UpdateVTP = false;
        clsVTP vtp = new clsVTP();

        public void BindingDataVTP()
        {
            txtGetIDVT.DataBindings.Clear();
            cbVTP_TenVT.DataBindings.Clear();
            txtVTP_SoLuong.DataBindings.Clear();

            txtGetIDVT.DataBindings.Add("Text", dgvPhong.DataSource, "MaVT");
            cbVTP_TenVT.DataBindings.Add("Text", dgvPhong.DataSource, "TenVT");
            txtVTP_SoLuong.DataBindings.Add("Text", dgvPhong.DataSource, "SoLuong");
        }

        public void loadDGV_VTP()
        {
            dgvPhong.DataSource = vtp.Display_VTP(int.Parse(txtGetIDphong.Text));

            DGVStyle(dgvPhong);

            dgvPhong.Columns["MaVT"].Visible = false;
            dgvPhong.Columns["TenVT"].HeaderText = "Tên vật tư";
            dgvPhong.Columns["SoLuong"].HeaderText = "Số lượng";

            BindingDataVTP();
        }

        private void btn_VTP_Click(object sender, EventArgs e)
        {
            panelVTP.Visible = true;
            loadDGV_VTP();
        }

        private void btnVTP_TurnBack_Click(object sender, EventArgs e)
        {
            panelVTP.Visible = false;
            loadDGV_Phong();
        }

        public void BtnVTP_SaveChangeVisibleFalse()
        {
            dgvPhong.Enabled = true;
            btnVTP_TurnBack.Enabled = true;
            btnVTP_Save.Visible = false;

            cbVTP_TenVT.Enabled = false;
            txtVTP_SoLuong.Enabled = false;
        }
        public void BtnVTP_SaveChangeVisibleTrue()
        {
            dgvPhong.Enabled = false;
            btnVTP_TurnBack.Enabled = false;
            btnVTP_Save.Visible = true;

            cbVTP_TenVT.Enabled = true;
            txtVTP_SoLuong.Enabled = true;
        }

        private void btnVTP_Update_Click(object sender, EventArgs e)
        {
            BtnVTP_SaveChangeVisibleTrue();

            btnVTP_Insert.Enabled = false;
            btnVTP_Del.Enabled = false;

            cbVTP_TenVT.Enabled = false;

            UpdateVTP = true;
        }

        private void btnVTP_Del_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Xóa vật tư này?", "Thông báo!", MessageBoxButtons.YesNo);
            if (tb == DialogResult.Yes)
            {
                int rec, MaVT = cbVTP_TenVT.SelectedIndex + 1;
                rec = vtp.Del_VTP(int.Parse(txtGetIDphong.Text), MaVT);
                if (rec > 0)
                {
                    MessageBox.Show("Xóa thành công!", "Thông báo!", MessageBoxButtons.OK);

                    loadDGV_VTP();
                }
                else
                    MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnVTP_Insert_Click(object sender, EventArgs e)
        {
            BtnVTP_SaveChangeVisibleTrue();

            btnVTP_Del.Enabled = false;
            btnVTP_Update.Enabled = false;

            InsertVTP = true;
        }
        
        private void btnVTP_Save_Click(object sender, EventArgs e)
        {
            int rec,MaVT = cbVTP_TenVT.SelectedIndex + 1;
            if(InsertVTP == true)
            {
                if (txtVTP_SoLuong.Text.Trim().Length == 0) txtVTP_SoLuong.Text = "0";
                rec = vtp.Insert_VTP(int.Parse(txtGetIDphong.Text), MaVT, int.Parse(txtVTP_SoLuong.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Thêm thành công!", "Thông báo!", MessageBoxButtons.OK);
                    BtnVTP_SaveChangeVisibleFalse();
                    btnVTP_Del.Enabled = true;
                    btnVTP_Update.Enabled = true;

                    InsertVTP = false;

                    loadDGV_VTP();
                }
                else if (rec == -2)
                {
                    MessageBox.Show("Vật tư đã tồn tại trong phòng!", "Thông báo!", MessageBoxButtons.OK);
                    cbVTP_TenVT.Focus();
                }
                else
                    MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
            else if (UpdateVTP == true)
            {
                if (txtVTP_SoLuong.Text.Trim().Length == 0) txtVTP_SoLuong.Text = "0";
                rec = vtp.Update_VTP(int.Parse(txtGetIDphong.Text), MaVT, int.Parse(txtVTP_SoLuong.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);
                    BtnVTP_SaveChangeVisibleFalse();
                    btnVTP_Del.Enabled = true;
                    btnVTP_Insert.Enabled = true;

                    cbVTP_TenVT.Enabled = true;

                    UpdateVTP = false;

                    loadDGV_VTP();
                }
                else
                    MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
            }
        }

        #endregion

        #region KhachHang
        clsKH kh = new clsKH();

        private void btnKH_insert_Click(object sender, EventArgs e)
        {
            frm_ThongTinKH frmTTKH = new frm_ThongTinKH();
            frmTTKH.Text = "Thêm khách hàng";
            frmTTKH.ShowDialog();
            loadDGV_KH();
        }

        private void btnTTKH_Update_Click(object sender, EventArgs e)
        {
            frm_ThongTinKH frmTTKH = new frm_ThongTinKH(int.Parse(txtGetIDKH.Text));
            frmTTKH.Text = "Cập nhật khách hàng";
            frmTTKH.ShowDialog();
            loadDGV_KH();
        }

        void BindingDataKH()
        {
            txtGetIDKH.DataBindings.Clear();

            txtGetIDKH.DataBindings.Add("Text", dgv_KhachHang.DataSource, "MaKH");
        }

        void loadDGV_KH()
        {
            dgv_KhachHang.DataSource = kh.Display_KH();

            DGVStyle(dgv_KhachHang);

            dgv_KhachHang.Columns["MaKH"].Visible = false;
            dgv_KhachHang.Columns["HoTen"].HeaderText = "Họ tên";
            dgv_KhachHang.Columns["DiaChi"].HeaderText = "Địa chỉ";
            dgv_KhachHang.Columns["SDT"].HeaderText = "SĐT";

            BindingDataKH();
        }
        #endregion

        #region ThuePhong
        bool InsertTP = false, UpdateTP = false;
        clsTP tp = new clsTP();

        void BindingDataTP_Date()
        {
            dtpTP_NgayThue.DataBindings.Clear();
            dtpTP_NgayDuKien.DataBindings.Clear();
            dtpTP_NgayTra.DataBindings.Clear();

            dtpTP_NgayThue.DataBindings.Add("Value", dgv_KhachHang.DataSource, "NgayThue", true);
            dtpTP_NgayDuKien.DataBindings.Add("Value", dgv_KhachHang.DataSource, "NgayDuKienTra", true);
            dtpTP_NgayTra.DataBindings.Add("Value", dgv_KhachHang.DataSource, "NgayTra", true);
        }

        void BindingDataTP()
        {
            txtGetIDMaTP.DataBindings.Clear();
            txtGetIDPH.DataBindings.Clear();
            cbTP_SoPH.DataBindings.Clear();

            txtGetIDMaTP.DataBindings.Add("Text", dgv_KhachHang.DataSource, "maThuePH");
            txtGetIDPH.DataBindings.Add("Text", dgv_KhachHang.DataSource, "MaPH");
            cbTP_SoPH.DataBindings.Add("Text", dgv_KhachHang.DataSource, "SoPH");

            BindingDataTP_Date();
        }

        void LoadDGV_TP()
        {
            dgv_KhachHang.DataSource = tp.Display_TP(int.Parse(txtGetIDKH.Text));

            DGVStyle(dgv_KhachHang);

            dgv_KhachHang.Columns["MaThuePH"].Visible = false;
            dgv_KhachHang.Columns["MaPH"].Visible = false;
            dgv_KhachHang.Columns["SoPH"].HeaderText = "Số phòng";
            dgv_KhachHang.Columns["NgayThue"].HeaderText = "Ngày thuê";
            dgv_KhachHang.Columns["NgayThue"].DefaultCellStyle.Format = "dd-MM-yyyy";
            dgv_KhachHang.Columns["NgayDuKienTra"].HeaderText = "Ngày dự kiến trả";
            dgv_KhachHang.Columns["NgayDuKienTra"].DefaultCellStyle.Format = "dd-MM-yyyy";
            dgv_KhachHang.Columns["NgayTra"].HeaderText = "Ngày trả";
            dgv_KhachHang.Columns["NgayTra"].DefaultCellStyle.Format = "dd-MM-yyyy";

            SqlDataReader dr = tp.Display_TPcbSoPhong();
            while (dr.Read())
            {
                cbTP_SoPH.Items.Add(dr["SoPH"].ToString());
            }

            BindingDataTP();
        }

        private void btnTP_TurnBack_Click(object sender, EventArgs e)
        {
            btnKH_insert.Visible = true;
            btnTTKH_Update.Visible = true;
            btnTP_TurnBack.Visible = false;

            panelTP.Enabled = false;

            loadDGV_KH();
        }

        private void btnTP_Save_Click(object sender, EventArgs e)
        {
            int rec, maPH = cbTP_SoPH.SelectedIndex + 1;
            string NT = dtpTP_NgayThue.Value.ToString("yyyy-MM-dd"),
                NDK = dtpTP_NgayDuKien.Value.ToString("yyyy-MM-dd");
            if(InsertTP == true)
            {
                rec = tp.Insert_TP(maPH, int.Parse(txtGetIDKH.Text), NT, NDK);
                if (rec > 0)
                {
                    MessageBox.Show("Thêm thành công!", "Thông báo!", MessageBoxButtons.OK);
                    btnTP_update.Enabled = true;
                    btnTP_Save.Enabled = false;
                    btnTP_TurnBack.Enabled = true;

                    dgv_KhachHang.Enabled = true;
                    cbTP_SoPH.Enabled = false;

                    InsertTP = false;

                    LoadDGV_TP();
                }
                else MessageBox.Show("Lổi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
            else if(UpdateTP == true)
            {
                rec = tp.Update_TP(int.Parse(txtGetIDMaTP.Text), maPH, int.Parse(txtGetIDKH.Text), NT, NDK);
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);
                    btnTP_Insert.Enabled = true;
                    btnTP_Save.Enabled = false;
                    btnTP_TurnBack.Enabled = true;

                    dgv_KhachHang.Enabled = true;
                    cbTP_SoPH.Enabled = false;

                    UpdateTP = false;

                    LoadDGV_TP();
                }
                else MessageBox.Show("Lổi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnNT_Save_Click(object sender, EventArgs e)
        {
            int rec, maPH = cbTP_SoPH.SelectedIndex + 1;
            string NT = dtpTP_NgayTra.Value.ToString("yyyy-MM-dd");

            rec = tp.Update_NT(int.Parse(txtGetIDMaTP.Text), NT);
            if (rec > 0)
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);
                btnTP_update.Enabled = true;
                btnTP_Insert.Enabled = true;
                btnTP_TurnBack.Enabled = true;
                btnNT_Save.Enabled = false;

                dgv_KhachHang.Enabled = true;

                LoadDGV_TP();
            }
            else MessageBox.Show("Lổi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
        }

        private void btnTP_update_Click(object sender, EventArgs e)
        {
            btnTP_Insert.Enabled = false;
            btnTP_Save.Enabled = true;
            btnTP_TurnBack.Enabled = false;

            dgv_KhachHang.Enabled = false;
            cbTP_SoPH.Enabled = true;

            UpdateTP = true;

            BindingDataTP_Date();
        }

        private void btnTP_Insert_Click(object sender, EventArgs e)
        {
            btnTP_update.Enabled = false;
            btnTP_Save.Enabled = true;
            btnTP_TurnBack.Enabled = false;

            dgv_KhachHang.Enabled = false;
            cbTP_SoPH.Enabled = true;

            InsertTP = true;
        }

        private void btnNT_update_Click(object sender, EventArgs e)
        {
            btnTP_update.Enabled = false;
            btnTP_Insert.Enabled = false;
            btnTP_TurnBack.Enabled = false;
            btnNT_Save.Enabled = true;

            dgv_KhachHang.Enabled = false;

            BindingDataTP_Date();
        }

        private void btnTP_Click(object sender, EventArgs e)
        {
            btnKH_insert.Visible = false;
            btnTTKH_Update.Visible = false;
            btnTP_TurnBack.Visible = true;

            panelTP.Enabled = true;

            LoadDGV_TP();
        }
        #endregion

        #region DichVu
        bool InsertDV = false, UpdateDV = false;
        clsDV dv = new clsDV();

        private void btnDV_Save_Click(object sender, EventArgs e)
        {
            int rec, MaKH, MaDV;
            MaKH = dv.GetMAKHfromCMND(cbDV_CMND.Text);
            MaDV = dv.GetMADVfromTenDV(cbDV_TenDV.Text);
            if(InsertDV == true)
            {
                if (MaKH > 0 && MaDV > 0)
                {
                    if (txtDV_SoLuong.Text.Trim().Length == 0) txtDV_SoLuong.Text = "0";
                    rec = dv.Insert_PhieuDV(MaDV, MaKH, int.Parse(txtDV_SoLuong.Text));
                    if (rec > 0)
                    {
                        MessageBox.Show("Thêm thành công!", "Thông báo!", MessageBoxButtons.OK);

                        btnDV_Del.Enabled = true;
                        btnDV_Update.Enabled = true;
                        btnDV_Save.Enabled = false;

                        dgv_DV.Enabled = true;
                        cbDV_CMND.Enabled = false;
                        cbDV_TenDV.Enabled = false;

                        txtDV_SoLuong.Enabled = false;

                        InsertDV = false;

                        loadDGV_DV();
                    }
                    else MessageBox.Show("Lỗi: " + rec.ToString(), "Thông báo!", MessageBoxButtons.OK);
                }
                else MessageBox.Show("Lỗi kết nối database!", "Thông báo!", MessageBoxButtons.OK);
            }
            else if(UpdateDV == true)
            {
                if (txtDV_SoLuong.Text.Trim().Length == 0) txtDV_SoLuong.Text = "0";
                rec = dv.Update_PhieuDV(int.Parse(txtGetIDPDV.Text), MaDV, MaKH, int.Parse(txtDV_SoLuong.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Cập nhật thành công!", "Thông báo!", MessageBoxButtons.OK);

                    btnDV_Del.Enabled = true;
                    btnDV_Insert.Enabled = true;
                    btnDV_Save.Enabled = false;

                    dgv_DV.Enabled = true;
                    cbDV_CMND.Enabled = false;
                    cbDV_TenDV.Enabled = false;

                    txtDV_SoLuong.Enabled = false;

                    UpdateDV = false;

                    loadDGV_DV();
                }
                else MessageBox.Show("Lỗi kết nốt database!", "Thông báo!", MessageBoxButtons.OK);
            }
        }

        private void btnDV_Update_Click(object sender, EventArgs e)
        {
            btnDV_Del.Enabled = false;
            btnDV_Insert.Enabled = false;
            btnDV_Save.Enabled = true;

            dgv_DV.Enabled = false;
            cbDV_CMND.Enabled = true;
            cbDV_TenDV.Enabled = true;

            txtDV_SoLuong.Enabled = true;

            UpdateDV = true;
        }

        private void btnDV_Del_Click(object sender, EventArgs e)
        {
            DialogResult tb = MessageBox.Show("Xóa phiếu dịch vụ này?", "Thông báo!", MessageBoxButtons.YesNo);
            if(tb == DialogResult.Yes)
            {
                int rec = dv.Del_PhieuDV(int.Parse(txtGetIDPDV.Text));
                if (rec > 0)
                {
                    MessageBox.Show("Xóa thành công!", "thông báo!", MessageBoxButtons.OK);
                    loadDGV_DV();
                }
            }
            
        }

        private void Main_QLKS_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnDV_Insert_Click(object sender, EventArgs e)
        {
            btnDV_Del.Enabled = false;
            btnDV_Update.Enabled = false;
            btnDV_Save.Enabled = true;

            dgv_DV.Enabled = false;
            cbDV_CMND.Enabled = true;
            cbDV_TenDV.Enabled = true;

            txtDV_SoLuong.Enabled = true;
            txtDV_SoLuong.Clear();

            InsertDV = true;
        }

        void BindingDataDV()
        {
            cbDV_CMND.DataBindings.Clear();
            cbDV_TenDV.DataBindings.Clear();
            txtDV_SoLuong.DataBindings.Clear();
            txtGetIDPDV.DataBindings.Clear();
            txtGetIDDV.DataBindings.Clear();
            txtGetIDKH_DV.DataBindings.Clear();

            cbDV_CMND.DataBindings.Add("Text", dgv_DV.DataSource, "CMND");
            cbDV_TenDV.DataBindings.Add("Text", dgv_DV.DataSource, "TenDV");
            txtDV_SoLuong.DataBindings.Add("Text", dgv_DV.DataSource, "SoLanDV");
            txtGetIDPDV.DataBindings.Add("Text", dgv_DV.DataSource, "MaPhieuDV");
            txtGetIDDV.DataBindings.Add("Text", dgv_DV.DataSource, "MaDV");
            txtGetIDKH_DV.DataBindings.Add("Text", dgv_DV.DataSource, "MaKH");
        }

        void loadDGV_DV()
        {
            dgv_DV.DataSource = dv.Display_PhieuDV();

            DGVStyle(dgv_DV);

            dgv_DV.Columns["MaPhieuDV"].Visible = false;
            dgv_DV.Columns["MaDV"].Visible = false;
            dgv_DV.Columns["MaKH"].Visible = false;

            dgv_DV.Columns["TenDV"].HeaderText = "Tên dịch vụ";
            dgv_DV.Columns["SoLanDV"].HeaderText = "Số lượng";

            SqlDataReader dr = dv.Display_DVcbCMND();
            while (dr.Read())
            {
                cbDV_CMND.Items.Add(dr["CMND"].ToString());
            }
            dr = dv.Display_DVcbTenDV();
            while (dr.Read())
            {
                cbDV_TenDV.Items.Add(dr["TenDV"].ToString());
            }

            BindingDataDV();
        }
        #endregion
    }
}
