﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace QLKS.Model
{
    class ClsProvider
    {
        public SqlConnection conn;
        public bool Connection()
        {
            string connectStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString.ToString();
            conn = new SqlConnection(connectStr);
            if (conn.State == ConnectionState.Closed || conn.State == ConnectionState.Broken)
            {
                conn.Open();
                return true;
            }
            else return false;
        }

        public void disconnection()
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
                conn.Dispose();
            }
        }
    }
}
